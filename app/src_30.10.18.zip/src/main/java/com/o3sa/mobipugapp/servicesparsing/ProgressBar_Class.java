package com.o3sa.mobipugapp.servicesparsing;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;

public class ProgressBar_Class {

	public static ProgressDialog progressDialog;

	public static Dialog dialog;

	public static void Progressbarshow(Context context) {
		progressDialog = new ProgressDialog(context);
		progressDialog.setMessage("Please wait...");
		//progressDialog.setCancelable(false);
		progressDialog.setCancelable(true);
		progressDialog.setIndeterminate(true);
		progressDialog.show();

	}

	public static void Progressbarcancel(Context context) {
		if (progressDialog != null) {
			progressDialog.dismiss();
		}
	}




}
