package com.o3sa.mobipugapp.fragments;

import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.o3sa.mobipugapp.R;
import com.o3sa.mobipugapp.dumpdata.DumpData;
import com.o3sa.mobipugapp.dumpdata.StoredObjects;
import com.o3sa.mobipugapp.uicomponents.BasicComponents;
import com.o3sa.mobipugapp.uicomponents.Constants;
import com.o3sa.mobipugapp.uicomponents.CustomRecyclerview;
import com.o3sa.mobipugapp.uicomponents.ViewpagerAdapter;

/**
 * Created by Kiran on 21-10-2018.
 */

public class ProductList extends Fragment {

    TextView ofrs_filtrs_tx;
    EditText ofrs_srch_tx;
    ImageView ofrs_menu_img,ofrs_filtr_img;
    RecyclerView ofrs_recycleviwe;
    BasicComponents components;

    LinearLayout prdct_lst_fltr_lay;
    private PopupWindow mPopupWindow;

    Integer[] ofrs_catgryimgs = {R.drawable.restarunt_sammpleimg,R.drawable.restarunt_sammpleimg,R.drawable.restarunt_sammpleimg,R.drawable.restarunt_sammpleimg,R.drawable.restarunt_sammpleimg};

    String[] price = {"05 - 10","10 - 15","15 - 20","20 - 25","25 - 30","30 - 35","35 - 40","40 - 45"};

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.offerslist,container,false);
        components=new BasicComponents(getActivity());

        intialization(v);
        return v;
    }

    public void intialization(View v){

        ofrs_menu_img = (ImageView)v.findViewById(R.id.ofrs_menu_img);
        ofrs_filtr_img = (ImageView)v.findViewById(R.id.ofrs_filtr_img);
        ofrs_srch_tx = (EditText) v.findViewById(R.id.ofrs_srch_tx);
        ofrs_filtrs_tx =(TextView)v.findViewById(R.id.ofrs_filtrs_tx);

        ofrs_recycleviwe = (RecyclerView)v.findViewById(R.id.ofrs_recycleviwe);

        prdct_lst_fltr_lay = (LinearLayout)v.findViewById(R.id.prdct_lst_fltr_lay);

        StoredObjects.offersarraylist.clear();

        for (int i = 0;i<ofrs_catgryimgs.length;i++){
            DumpData dumpData = new DumpData();
            dumpData.ofrscatgryimglist = ofrs_catgryimgs[i];
            StoredObjects.offersarraylist.add(dumpData);
        }

        CustomRecyclerview recyclerview = new CustomRecyclerview(getActivity());
        recyclerview.Assigndatatorecyleview(ofrs_recycleviwe,StoredObjects.offersarraylist,"productslist",
                                            Constants.Listview, 0, Constants.ver_orientation,R.layout.productlistitem);

        assigndata();

    }

    public void assigndata(){

        components.CustomizeImageview(ofrs_menu_img, new int[]{20,20}, R.drawable.pink_searchicon, new int[]{0,0,0,0});
        components.CustomizeImageview(ofrs_filtr_img, new int[]{20,20}, R.drawable.filter_icon_new, new int[]{0,0,0,0});
        components.CustomizeEditview(ofrs_srch_tx, Constants.Medium,R.color.thik_grey,R.color.thik_grey,getActivity().getApplicationContext().getResources().getString(R.string.search),0,true,Constants.MatchLeftNormal+Constants.Roboto, new int[]{0,0,0,0});
        components.CustomizeTextview(ofrs_filtrs_tx, Constants.Normal,R.color.sport_shoos_txt_clr,getActivity().getApplicationContext().getResources().getString(R.string.filtrs),Constants.WrapCenterNormal+Constants.Roboto, new int[]{10,0,0,0});

        prdct_lst_fltr_lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Productfilterpopup(prdct_lst_fltr_lay);
            }
        });

    }

    private void Productfilterpopup(LinearLayout viewpager_lay){

        LayoutInflater mLayoutInflater=LayoutInflater.from(getActivity());

        View mView=mLayoutInflater.inflate(R.layout.productfilterpopup, null);

        mPopupWindow=new PopupWindow(mView, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, true);
        mPopupWindow.setContentView(mView);

        ImageView mange_uparow_img = (ImageView)mView.findViewById(R.id.mange_uparow_img);

        LinearLayout select_ctgry_lay = (LinearLayout)mView.findViewById(R.id.select_ctgry_lay);
        LinearLayout select_subctgry_lay = (LinearLayout)mView.findViewById(R.id.select_subctgry_lay);
        EditText subctgry_edtx = (EditText)mView.findViewById(R.id.subctgry_edtx);
        EditText ctgry_edtx = (EditText)mView.findViewById(R.id.ctgry_edtx);

        Button filter_done_btn = (Button)mView.findViewById(R.id.filter_done_btn);

        components.CustomizeEditview(subctgry_edtx, Constants.Medium,R.color.thik_grey,R.color.thik_grey,getActivity().getApplicationContext().getResources().getString(R.string.sel_subcategory),0,false,Constants.MatchLeftNormal+Constants.Roboto, new int[]{0,0,0,0});
        components.CustomizeEditview(ctgry_edtx, Constants.Medium,R.color.thik_grey,R.color.thik_grey,getActivity().getApplicationContext().getResources().getString(R.string.seclt_catgry),0,false,Constants.MatchLeftNormal+Constants.Roboto, new int[]{0,0,0,0});

        components.CustomizeButton(filter_done_btn, Constants.XXNormal,R.color.white,getActivity().getApplicationContext().getResources().getString(R.string.searchproduct),R.drawable.list_bottom_bg,Constants.MatchCenterNormal+Constants.Roboto, new int[]{0,42}, new int[]{0,10,0,5});

        Drawable d = new ColorDrawable(Color.WHITE);

        d.setAlpha(200);

        mPopupWindow.setBackgroundDrawable(new BitmapDrawable());

        mPopupWindow.showAsDropDown(viewpager_lay,0,0, Gravity.CENTER);

        //getWindow().setBackgroundDrawable(d);

        mPopupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
                Drawable d = new ColorDrawable(Color.WHITE);
                //getWindow().setBackgroundDrawable(d);
            }
        });


      select_ctgry_lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        select_subctgry_lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        filter_done_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mPopupWindow.dismiss();
            }
        });


    }

}

