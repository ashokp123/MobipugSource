package com.o3sa.mobipugapp.customerfragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.o3sa.mobipugapp.R;
import com.o3sa.mobipugapp.dumpdata.DumpData;
import com.o3sa.mobipugapp.dumpdata.StoredObjects;
import com.o3sa.mobipugapp.sidemenu.Sidemenu;
import com.o3sa.mobipugapp.uicomponents.BasicComponents;
import com.o3sa.mobipugapp.uicomponents.Constants;
import com.o3sa.mobipugapp.uicomponents.CustomRecyclerview;

/**
 * Created by Kiran on 27-10-2018.
 */

public class SubCategoryList extends Fragment {

    RecyclerView subcat_recycleviwe;
    BasicComponents components;

    String[] sbcat_names  = {"Veg","Sweets","Sea Food","Kababs","Chicken","Mutton","Beef"};
     Integer[] sbcat_imgs  = {R.drawable.ic_launcher,R.drawable.ic_launcher,R.drawable.ic_launcher,R.drawable.ic_launcher,
            R.drawable.ic_launcher,R.drawable.ic_launcher,R.drawable.ic_launcher};

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.sub_category,container,false);

        components=new BasicComponents(getActivity());
        components.CustomizeTextview(Sidemenu.menu_title, Constants.XXLarge4,R.color.black,getActivity().getResources().getString(R.string.subcategory_lst),Constants.WrapLeftNormal+Constants.Roboto, new int[]{0,0,0,0});

        intialization(v);
        return v;
    }

    public void intialization(View v){

        subcat_recycleviwe = (RecyclerView)v.findViewById(R.id.subcat_recycleviwe);
        StoredObjects.subcategoryarraylist.clear();

        for (int i = 0;i<sbcat_names.length;i++){
            DumpData dumpData = new DumpData();
            dumpData.sbcat_nmslist = sbcat_names[i];
            dumpData.sbcat_imgslist= sbcat_imgs[i];

            StoredObjects.subcategoryarraylist.add(dumpData);
        }

        CustomRecyclerview recyclerview = new CustomRecyclerview(getActivity());
        recyclerview.Assigndatatorecyleview(subcat_recycleviwe,StoredObjects.subcategoryarraylist,"subcategry", Constants.Listview,0, Constants.ver_orientation,R.layout.subcategory_listitems);

    }



}
