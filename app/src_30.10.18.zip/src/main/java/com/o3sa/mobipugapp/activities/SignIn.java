package com.o3sa.mobipugapp.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.o3sa.mobipugapp.R;
import com.o3sa.mobipugapp.uicomponents.BasicComponents;
import com.o3sa.mobipugapp.uicomponents.Constants;

/**
 * Created by android_2 on 10/11/2018.
 */

public class SignIn extends Fragment {

    EditText sgin_emal_edtx,sgin_pswd_edtx;
    TextView sgin_frgtpswd_txt;
    Button sgin_ctnue_btn;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.sign_in,container,false);
        intialization(v);
        return v;
    }

    public void intialization(View v){

        sgin_emal_edtx =(EditText)v.findViewById(R.id.sgin_emal_edtx);
        sgin_pswd_edtx= (EditText)v.findViewById(R.id.sgin_pswd_edtx);
        sgin_frgtpswd_txt =(TextView)v.findViewById(R.id.sgin_frgtpswd_txt);
        sgin_ctnue_btn = (Button)v.findViewById(R.id.sgin_ctnue_btn);

        sgin_ctnue_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //startActivity(new Intent(LandingPage.this,LoginPage.class));
            }
        });

        assigndata();

    }

    public void assigndata(){

        BasicComponents components = new BasicComponents(getActivity());

        components.CustomizeEditview(sgin_emal_edtx, Constants.XNormal,R.color.gray1,R.color.lyt_grey,getActivity().getApplicationContext().getResources().getString(R.string.email),R.drawable.shadoweffect,true,Constants.MatchCenterNormal+Constants.Roboto, new int[]{0,25,0,0});
        components.CustomizeEditview(sgin_pswd_edtx,Constants.XNormal,R.color.gray1,R.color.lyt_grey,getActivity().getApplicationContext().getResources().getString(R.string.paswrd),R.drawable.shadoweffect,true,Constants.MatchCenterNormal+Constants.Roboto, new int[]{0,15,0,0});
        components.CustomizeTextview(sgin_frgtpswd_txt,Constants.Medium,R.color.gray2,getActivity().getApplicationContext().getResources().getString(R.string.frgtpswd),Constants.WrapCenterNormal+Constants.Roboto, new int[]{0,20,0,0});
        components.CustomizeButton(sgin_ctnue_btn, Constants.XNormal,R.color.white,getActivity().getApplicationContext().getResources().getString(R.string.cntinue),R.drawable.cntinue_btn_bg,Constants.MatchCenterNormal+Constants.SFUIText, new int[]{0,45}, new int[]{0,20,0,0});
        components.SetPasswordHint(sgin_pswd_edtx);
    }

}
