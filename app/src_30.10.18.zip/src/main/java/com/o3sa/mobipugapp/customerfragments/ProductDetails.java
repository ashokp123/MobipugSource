package com.o3sa.mobipugapp.customerfragments;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.TextView;

import com.o3sa.mobipugapp.R;
import com.o3sa.mobipugapp.activities.LandingPage;
import com.o3sa.mobipugapp.activities.LoginPage;
import com.o3sa.mobipugapp.database.Database;
import com.o3sa.mobipugapp.dumpdata.DumpData;
import com.o3sa.mobipugapp.dumpdata.StoredObjects;
import com.o3sa.mobipugapp.fragments.ManageOffers;
import com.o3sa.mobipugapp.sidemenu.Sidemenu;
import com.o3sa.mobipugapp.uicomponents.BasicComponents;
import com.o3sa.mobipugapp.uicomponents.Constants;
import com.o3sa.mobipugapp.uicomponents.Customviewpager;
import com.o3sa.mobipugapp.uicomponents.ViewpagerAdapter;

import java.util.ArrayList;

//Created by android-4 on 10/22/2018.


public class ProductDetails extends Fragment {

    BasicComponents components;

    ViewPager prdct_viewpager;
    LinearLayout viewPagerCountDots;
    ViewpagerAdapter viewpagerAdapter;

    TextView prdct_titl_txt,prdct_price_txt,prdct_actual_price_txt,prdct_dscnt_txt,prdct_ratng_txt;
    RatingBar prdct_rating;
    ImageView prdct_share_img,prdct_like_img;
    TextView prdct_dtls_txt,prdct_dtls_txt1,prdct_dtls_txt2,prdct_dtls_txt3,prdct_addtocart_txt;
    Button prdct_vw_dtls_btn,addtocart_btn;
    Integer [] prdct_pg_imgs = {R.drawable.restarunt_sammpleimg,R.drawable.restarunt_sammpleimg,R.drawable.restarunt_sammpleimg,
                                R.drawable.restarunt_sammpleimg,R.drawable.restarunt_sammpleimg};

    String [] names = {"15 mins ago","15 mins ago","15 mins ago"};

    int count=0;
    Database database;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.product,container,false);

        database=new Database(getActivity());
        database.getAllDevice();
        components=new BasicComponents(getActivity());
        components.CustomizeTextview(Sidemenu.menu_title, Constants.XXLarge4,R.color.black,getActivity().getResources().getString(R.string.product_details),Constants.WrapLeftNormal+Constants.Roboto, new int[]{0,0,0,0});

        init(v);
        return v;
    }

    public void init(View b){

        prdct_titl_txt = (TextView) b.findViewById(R.id.prdct_titl_txt);
        prdct_price_txt = (TextView)b.findViewById(R.id.prdct_price_txt);
        prdct_actual_price_txt = (TextView)b.findViewById(R.id.prdct_actual_price_txt);
        prdct_dscnt_txt = (TextView)b.findViewById(R.id.prdct_dscnt_txt);
        prdct_ratng_txt = (TextView)b.findViewById(R.id.prdct_ratng_txt);

        prdct_dtls_txt = (TextView)b.findViewById(R.id.prdct_dtls_txt);
        prdct_dtls_txt1 = (TextView)b.findViewById(R.id.prdct_dtls_txt1);
        prdct_dtls_txt2 = (TextView)b.findViewById(R.id.prdct_dtls_txt2);
        prdct_dtls_txt3 = (TextView)b.findViewById(R.id.prdct_dtls_txt3);

        prdct_vw_dtls_btn = (Button) b.findViewById(R.id.prdct_vw_dtls_btn);
        addtocart_btn = (Button)b.findViewById(R.id.addtocart_btn);

        prdct_rating = (RatingBar) b.findViewById(R.id.prdct_rating);

        prdct_share_img = (ImageView)b.findViewById(R.id.prdct_share_img);
        prdct_like_img = (ImageView)b.findViewById(R.id.prdct_like_img);
        prdct_viewpager = (ViewPager)b.findViewById(R.id.prdct_viewpager);
        viewPagerCountDots = (LinearLayout)b.findViewById(R.id.viewPagerCountDots);
        prdct_addtocart_txt=(TextView) b.findViewById(R.id.prdct_addtocart_txt);

        StoredObjects.prdct_pg_list.clear();
        for (int i = 0;i<prdct_pg_imgs.length;i++){
            DumpData dumpData = new DumpData();
            dumpData.prdct_pg_imgs = prdct_pg_imgs[i];

            StoredObjects.prdct_pg_list.add(dumpData);
        }

        StoredObjects.prdct_pg_list1.clear();
        for (int i = 0;i<names.length;i++){
            DumpData dumpData = new DumpData();
            dumpData.names = names[i];

            StoredObjects.prdct_pg_list1.add(dumpData);
        }


        Customviewpager customviewpager=new Customviewpager();
        customviewpager.Customviewpager(getActivity(),prdct_viewpager,viewpagerAdapter,StoredObjects.prdct_pg_list,viewPagerCountDots,"prdct_viewpager",R.layout.viewpagerlistitem);

        setData();
        addtocart_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                count=count+1;
                StoredObjects.mycart_array.clear();
                StoredObjects.mycart_array = database.GetMyCartData(StoredObjects.UserId);

               /* boolean checkitemexist = database.checkproductfromcart(StoredObjects.UserId, "1");
                if (checkitemexist == true) {

                        StoredObjects.ToastMethod(getActivity().getResources().getString(R.string.addedtocart),getActivity());
                }else{
                    database.MyCart_insert(StoredObjects.UserId, "1",  "Sports shoes", "1","",
                           ''1000");
                    fragmentcalling(new Mycart());
                }*/
                database.MyCart_insert(StoredObjects.UserId, count+"",  "Sports shoes", "1","",
                        "1000");
                fragmentcalling(new OrdersMain());

            }
        });

    }
    public void fragmentcalling( Fragment fragment){

        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.frame_container, fragment).commit();

    }


    private void setData() {

        components.CustomizeWithBgTextview(prdct_addtocart_txt, Constants.XXXNormal,R.color.white,getActivity().getResources().getString(R.string.addtocart),R.drawable.addtocart_bg,Constants.WrapCenterNormal+Constants.Gibson, new int[]{10,5,0,5});

        components.CustomizeTextview(prdct_titl_txt, Constants.XXXNormal,R.color.sport_shoos_txt_clr,getActivity().getResources().getString(R.string.ivokes),Constants.WrapLeftBold+Constants.Roboto, new int[]{12,12,10,0});
        components.CustomizeTextview(prdct_price_txt,Constants.XNormal,R.color.blue_color,getActivity().getResources().getString(R.string.three_ten),Constants.WrapLeftNormal+Constants.Roboto, new int[]{12,0,0,0});
        components.CustomizeTextview(prdct_actual_price_txt,Constants.Normal,R.color.rvw_txt_clr,getActivity().getResources().getString(R.string.nine_nine),Constants.WrapLeftNormal+Constants.Roboto, new int[]{10,0,0,0});
        components.CustomizeTextview(prdct_dscnt_txt,Constants.Normal,R.color.txt_clr,getActivity().getResources().getString(R.string.fifty),Constants.WrapLeftNormal+Constants.Roboto, new int[]{5,0,0,0});

        components.CustomizeTextview(prdct_ratng_txt,Constants.Normal,R.color.txt_clr,getActivity().getResources().getString(R.string.fourty),Constants.WrapLeftNormal+Constants.Roboto, new int[]{5,0,0,0});
        components.CustomizeTextview(prdct_dtls_txt,Constants.Large,R.color.txt_clr,getActivity().getResources().getString(R.string.prdct),Constants.WrapLeftNormal+Constants.Gibson, new int[]{12,12,0,0});
        components.CustomizeTextview(prdct_dtls_txt1,Constants.Normal,R.color.txt_clr,getActivity().getResources().getString(R.string.are),Constants.WrapLeftNormal+Constants.Roboto, new int[]{12,5,0,0});
        components.CustomizeTextview(prdct_dtls_txt2,Constants.Normal,R.color.txt_clr,getActivity().getResources().getString(R.string.if_u),Constants.WrapLeftNormal+Constants.Roboto, new int[]{12,10,0,0});
        components.CustomizeTextview(prdct_dtls_txt3,Constants.Normal,R.color.txt_clr,getActivity().getResources().getString(R.string.combng),Constants.WrapLeftNormal+Constants.Roboto, new int[]{12,10,0,10});

        components.CustomizeImageview(prdct_share_img, new int[]{23,23}, R.drawable.share, new int[]{0,0,0,0});
        components.CustomizeImageview(prdct_like_img, new int[]{23,23}, R.drawable.heart, new int[]{25,0,0,0});

        components.CustomizeButton(prdct_vw_dtls_btn, Constants.XXNormal,R.color.txt_clr,getActivity().getResources().getString(R.string.vw_detls),R.drawable.button_bg,Constants.MatchCenterNormal+Constants.Roboto, new int[]{0,50}, new int[]{0,0,0,0});
          components.CustomizeButton(addtocart_btn,Constants.XNormal,R.color.white,getActivity().getResources().getString(R.string.addtocart), R.drawable.addtocart_bg, Constants.MatchCenterNormal+Constants.SFUIText, new int[]{0,50}, new int[]{0,0,0,10});

    }

}
