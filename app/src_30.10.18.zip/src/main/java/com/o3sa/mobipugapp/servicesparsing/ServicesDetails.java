package com.o3sa.mobipugapp.servicesparsing;

import android.os.CountDownTimer;

import org.apache.http.NameValuePair;

import java.util.ArrayList;
import java.util.List;

public class ServicesDetails {

    public String url = "";
    //public ArrayList<HashMap<String,String>> parameters = new ArrayList<>();
    public String[][] parameters = new String[15][15];
    public String parse_type;
    public int param_count = 0;
    public List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(20);
    public String Result = "";
    public CountDownTimer countDown;

}
