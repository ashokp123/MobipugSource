package com.o3sa.mobipugapp.activities;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.o3sa.mobipugapp.R;
import com.o3sa.mobipugapp.uicomponents.BasicComponents;
import com.o3sa.mobipugapp.uicomponents.Constants;

/**
 * Created by android_2 on 10/27/2018.
 */

public class VendorRegistration extends Fragment {

    EditText vreg_idprf_edtx,vreg_pancrd_edtx,vreg_fulnme_edtx,vreg_acntnmbr_edtx,vreg_ifsc_edtx,vreg_pakgetype_edtx;
    ImageView vreg_idprf_img,vreg_pancrd_img,vreg_fulnme_img,vreg_acntnmbr_img,vreg_ifsc_img,vreg_pakgetype_img;
    TextView vreg_bnkdetls_txt;
    Button vreg_cntnue_btn;

    BasicComponents components;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.vendor_registration,container,false);
        components = new BasicComponents(getActivity());

        intialization(v);
        return v;
    }

    public void intialization(View v){

        vreg_idprf_edtx =(EditText)v.findViewById(R.id.vreg_idprf_edtx);
        vreg_pancrd_edtx =(EditText)v.findViewById(R.id.vreg_pancrd_edtx);
        vreg_fulnme_edtx =(EditText)v.findViewById(R.id.vreg_fulnme_edtx);
        vreg_acntnmbr_edtx =(EditText)v.findViewById(R.id.vreg_acntnmbr_edtx);
        vreg_ifsc_edtx =(EditText)v.findViewById(R.id.vreg_ifsc_edtx);
        vreg_pakgetype_edtx =(EditText)v.findViewById(R.id.vreg_pakgetype_edtx);

        vreg_idprf_img=(ImageView)v.findViewById(R.id.vreg_idprf_img);
        vreg_pancrd_img=(ImageView)v.findViewById(R.id.vreg_pancrd_img);
        vreg_fulnme_img = (ImageView)v.findViewById(R.id.vreg_fulnme_img);
        vreg_acntnmbr_img = (ImageView)v.findViewById(R.id.vreg_acntnmbr_img);
        vreg_ifsc_img = (ImageView)v.findViewById(R.id.vreg_ifsc_img);
        vreg_pakgetype_img = (ImageView)v.findViewById(R.id.vreg_pakgetype_img);

        vreg_bnkdetls_txt = (TextView)v.findViewById(R.id.vreg_bnkdetls_txt);

        vreg_cntnue_btn=(Button) v.findViewById(R.id.vreg_cntnue_btn);


        assigndata();
    }

    public void assigndata() {

        components.CustomizeEditview(vreg_idprf_edtx, Constants.Medium, R.color.black, R.color.white, getActivity().getApplicationContext().getResources().getString(R.string.idproof_mndtry),0, true, Constants.MatchCenterNormal + Constants.Roboto, new int[]{0,0,0,0});
        components.CustomizeEditview(vreg_pancrd_edtx, Constants.Medium, R.color.black, R.color.white, getActivity().getApplicationContext().getResources().getString(R.string.pancard_mndtry),0, true, Constants.MatchCenterNormal + Constants.Roboto, new int[]{0,0,0,0});
        components.CustomizeEditview(vreg_fulnme_edtx, Constants.Medium, R.color.black, R.color.white, getActivity().getApplicationContext().getResources().getString(R.string.fullname_mndtry),0, true, Constants.MatchCenterNormal + Constants.Roboto, new int[]{0,0,0,0});
        components.CustomizeEditview(vreg_acntnmbr_edtx, Constants.Medium, R.color.black, R.color.white, getActivity().getApplicationContext().getResources().getString(R.string.accntNum_mndtry),0, true, Constants.MatchCenterNormal + Constants.Roboto, new int[]{0,0,0,0});
        components.CustomizeEditview(vreg_ifsc_edtx, Constants.Medium, R.color.black, R.color.white, getActivity().getApplicationContext().getResources().getString(R.string.ifcs_code_mndtry),0, true, Constants.MatchCenterNormal + Constants.Roboto, new int[]{0,0,0,0});
        components.CustomizeEditview(vreg_pakgetype_edtx, Constants.Medium, R.color.black, R.color.white, getActivity().getApplicationContext().getResources().getString(R.string.packagetype),0, true, Constants.MatchCenterNormal + Constants.Roboto, new int[]{0,0,0,0});

        components.CustomizeImageview(vreg_idprf_img, new int[]{20,15},R.drawable.dropdown_icon, new int[]{0,0,0,0});
        components.CustomizeImageview(vreg_pancrd_img, new int[]{20,15},R.drawable.dropdown_icon, new int[]{0,0,0,0});
        components.CustomizeImageview(vreg_fulnme_img, new int[]{20,15},R.drawable.dropdown_icon, new int[]{0,0,0,0});
        components.CustomizeImageview(vreg_acntnmbr_img, new int[]{20,15},R.drawable.dropdown_icon, new int[]{0,0,0,0});
        components.CustomizeImageview(vreg_ifsc_img, new int[]{20,15},R.drawable.dropdown_icon, new int[]{0,0,0,0});
        components.CustomizeImageview(vreg_pakgetype_img, new int[]{20,15},R.drawable.dropdown_icon, new int[]{0,0,0,0});

        components.CustomizeTextview(vreg_bnkdetls_txt, Constants.XNormal,R.color.white,getActivity().getApplicationContext().getResources().getString(R.string.bnkdetails),Constants.WrapLeftNormal+Constants.Roboto, new int[]{16,20,0,0});

        components.CustomizeButton(vreg_cntnue_btn, Constants.Normal,R.color.white,getActivity().getApplicationContext().getResources().getString(R.string.cntinue),R.drawable.cntinue_btn_bg,Constants.MatchCenterNormal+Constants.SFUIText, new int[]{0,45}, new int[]{0,15,0,35});

    }

}
