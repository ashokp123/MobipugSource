package com.o3sa.mobipugapp.uicomponents;

/**
 * Created by shrythi on 4/9/2018.
 */

public interface OnLoadMoreListener {
    void onLoadMore();
}