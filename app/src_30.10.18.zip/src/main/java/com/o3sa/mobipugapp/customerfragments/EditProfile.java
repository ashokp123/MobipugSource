package com.o3sa.mobipugapp.customerfragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.o3sa.mobipugapp.R;
import com.o3sa.mobipugapp.uicomponents.BasicComponents;
import com.o3sa.mobipugapp.uicomponents.Constants;

/**
 * Created by android_2 on 10/24/2018.
 */

public class EditProfile extends Fragment {

    EditText edtprf_nme_edtx,edtprf_mble_edtx,edtprf_emal_edtx,edtprf_pswd_edtx,edtprf_cnfmpswd_edtx;
    TextView edtprf_nme_tx,edtprf_mble_tx,edtprf_emal_tx,edtprf_pswd_tx,edtprf_cnfmpswd_tx;
    Button edtprf_save_btn;

    BasicComponents components;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.edit_profile,container,false);
        components = new BasicComponents(getActivity());
        intialization(v);
        return v;
    }

    public void intialization(View v) {

        edtprf_nme_edtx = (EditText) v.findViewById(R.id.edtprf_nme_edtx);
        edtprf_mble_edtx = (EditText) v.findViewById(R.id.edtprf_mble_edtx);
        edtprf_emal_edtx = (EditText) v.findViewById(R.id.edtprf_emal_edtx);
        edtprf_pswd_edtx = (EditText) v.findViewById(R.id.edtprf_pswd_edtx);
        edtprf_cnfmpswd_edtx = (EditText) v.findViewById(R.id.edtprf_cnfmpswd_edtx);

        edtprf_nme_tx =(TextView) v.findViewById(R.id.edtprf_nme_tx);
        edtprf_mble_tx = (TextView) v.findViewById(R.id.edtprf_mble_tx);
        edtprf_emal_tx=  (TextView)v.findViewById(R.id.edtprf_emal_tx);
        edtprf_pswd_tx =(TextView)v. findViewById(R.id.edtprf_pswd_tx);
        edtprf_cnfmpswd_tx = (TextView) v.findViewById(R.id.edtprf_cnfmpswd_tx);

        edtprf_save_btn = (Button) v.findViewById(R.id.edtprf_save_btn);

        assigndata();

    }

    public void assigndata() {

        components.CustomizeEditview(edtprf_nme_edtx, Constants.XNormal, R.color.black, R.color.lyt_grey, getActivity().getApplicationContext().getResources().getString(R.string.name),0, true, Constants.MatchCenterNormal + Constants.Roboto, new int[]{5,10,5,0});
        components.CustomizeEditview(edtprf_mble_edtx, Constants.XNormal, R.color.black, R.color.lyt_grey, getActivity().getApplicationContext().getResources().getString(R.string.mobile),0, true, Constants.MatchCenterNormal + Constants.Roboto, new int[]{5,10,5,0});
        components.CustomizeEditview(edtprf_emal_edtx, Constants.XNormal, R.color.black, R.color.lyt_grey, getActivity().getApplicationContext().getResources().getString(R.string.email),0, true, Constants.MatchCenterNormal + Constants.Roboto, new int[]{5,10,5,0});
        components.CustomizeEditview(edtprf_pswd_edtx, Constants.XNormal, R.color.black, R.color.lyt_grey, getActivity().getApplicationContext().getResources().getString(R.string.paswrd),0, true, Constants.MatchCenterNormal + Constants.Roboto, new int[]{5,10,5,0});
        components.CustomizeEditview(edtprf_cnfmpswd_edtx, Constants.XNormal, R.color.black, R.color.lyt_grey, getActivity().getApplicationContext().getResources().getString(R.string.confrmpassword),0, true, Constants.MatchCenterNormal + Constants.Roboto, new int[]{5,10,5,0});

        components.CustomizeTextview(edtprf_nme_tx,Constants.XNormal,R.color.black,getActivity().getApplicationContext().getResources().getString(R.string.name),Constants.WrapLeftNormal+Constants.SFUIText, new int[]{5,10,0,0});
        components.CustomizeTextview(edtprf_mble_tx,Constants.XNormal,R.color.black,getActivity().getApplicationContext().getResources().getString(R.string.mobile),Constants.WrapLeftNormal+Constants.SFUIText, new int[]{5,10,0,0});
        components.CustomizeTextview(edtprf_emal_tx,Constants.XNormal,R.color.black,getActivity().getApplicationContext().getResources().getString(R.string.email),Constants.WrapLeftNormal+Constants.SFUIText, new int[]{5,10,0,0});
        components.CustomizeTextview(edtprf_pswd_tx,Constants.XNormal,R.color.black,getActivity().getApplicationContext().getResources().getString(R.string.paswrd),Constants.WrapLeftNormal+Constants.SFUIText, new int[]{5,10,0,0});
        components.CustomizeTextview(edtprf_cnfmpswd_tx,Constants.XNormal,R.color.black,getActivity().getApplicationContext().getResources().getString(R.string.confrmpassword),Constants.WrapLeftNormal+Constants.SFUIText, new int[]{5,10,0,0});

        components.CustomizeButton(edtprf_save_btn, Constants.XNormal, R.color.white, getActivity().getApplicationContext().getResources().getString(R.string.save), R.drawable.cntinue_btn_bg, Constants.MatchCenterNormal + Constants.SFUIText, new int[]{0, 45}, new int[]{0, 20, 0, 0});

        edtprf_mble_edtx.setInputType(InputType.TYPE_CLASS_NUMBER);
        edtprf_pswd_edtx.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        edtprf_cnfmpswd_edtx.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);

    }

}
