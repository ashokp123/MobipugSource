package com.o3sa.mobipugapp.fragments;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;

import com.o3sa.mobipugapp.R;
import com.o3sa.mobipugapp.uicomponents.BasicComponents;
import com.o3sa.mobipugapp.uicomponents.Constants;

import java.util.Calendar;

/**
 * Created by android_2 on 10/16/2018.
 */

public class AddOffer extends Fragment {

   private static TextView adofr_ofrtpe_tx,adofr_publc_tx,adofr_private_tx,adofr_brndnme_tx,adofr_prce_tx,adofr_brndprce_tx,adofr_brndscunt_tx,
            adofr_ratngprcnt_tx,adofr_strtdate_tx,adofr_dsplydate_tx,adofr_enddate_tx,adofr_dsplyenddate_tx;

    TextView adofr_dscntype_edtx;
    ImageView adofr_slctctgry_img,adofr_slctsbctgry_img,adofr_prdct_img,adofr_catgry_img,adofr_dscntype_img,adofr_dsplydate_img,adofr_dsplyendate_img;
    RadioButton adofr_radiobutn,adofr_radiobutnone;
    Button adofr_srch_btn;

    EditText adofr_prdct_edtx,adofr_slctctgry_edtx,adofr_slctsbctgry_edtx;
    LinearLayout adofr_slctctgry_lay,adofr_slctsbctgry_lay,adofr_prdct_lay,adofr_dscntype_lay;
    BasicComponents components;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.add_offer,container,false);

        components=new BasicComponents(getActivity());
        intialization(v);

        return v;
    }

    public void intialization(View v){

        adofr_slctctgry_lay = (LinearLayout)v.findViewById(R.id.adofr_slctctgry_lay);
        adofr_slctsbctgry_lay = (LinearLayout)v.findViewById(R.id.adofr_slctsbctgry_lay);
        adofr_prdct_lay = (LinearLayout)v.findViewById(R.id.adofr_prdct_lay);
        adofr_dscntype_lay = (LinearLayout)v.findViewById(R.id.adofr_dscntype_lay);

        adofr_slctctgry_edtx =(EditText) v.findViewById(R.id.adofr_slctctgry_edtx);
        adofr_slctsbctgry_edtx= (EditText) v.findViewById(R.id.adofr_slctsbctgry_edtx);
        adofr_prdct_edtx =(EditText)v.findViewById(R.id.adofr_prdct_edtx);
        adofr_dscntype_edtx =(TextView)v.findViewById(R.id.adofr_dscntype_edtx);

        adofr_ofrtpe_tx = (TextView)v.findViewById(R.id.adofr_ofrtpe_tx);
        adofr_publc_tx = (TextView)v.findViewById(R.id.adofr_publc_tx);
        adofr_private_tx = (TextView)v.findViewById(R.id.adofr_private_tx);
        adofr_brndnme_tx =(TextView)v.findViewById(R.id.adofr_brndnme_tx);
        adofr_prce_tx =(TextView)v.findViewById(R.id.adofr_prce_tx);
        adofr_brndprce_tx =(TextView)v.findViewById(R.id.adofr_brndprce_tx);
        adofr_brndscunt_tx =(TextView)v.findViewById(R.id.adofr_brndscunt_tx);
        adofr_ratngprcnt_tx =(TextView)v.findViewById(R.id.adofr_ratngprcnt_tx);
        adofr_strtdate_tx =(TextView)v.findViewById(R.id.adofr_strtdate_tx);
        adofr_dsplydate_tx =(TextView)v.findViewById(R.id.adofr_dsplydate_tx);
        adofr_enddate_tx =(TextView)v.findViewById(R.id.adofr_enddate_tx);
        adofr_dsplyenddate_tx =(TextView)v.findViewById(R.id.adofr_dsplyenddate_tx);

        adofr_slctctgry_img = (ImageView)v.findViewById(R.id.adofr_slctctgry_img);
        adofr_slctsbctgry_img = (ImageView)v.findViewById(R.id.adofr_slctsbctgry_img);
        adofr_prdct_img = (ImageView)v.findViewById(R.id.adofr_prdct_img);
        adofr_catgry_img = (ImageView)v.findViewById(R.id.adofr_catgry_img);
        adofr_dscntype_img = (ImageView)v.findViewById(R.id.adofr_dscntype_img);
        adofr_dsplydate_img = (ImageView)v.findViewById(R.id.adofr_dsplydate_img);
        adofr_dsplyendate_img = (ImageView)v.findViewById(R.id.adofr_dsplyendate_img);

        adofr_radiobutn = (RadioButton)v.findViewById(R.id.adofr_radiobutn);
        adofr_radiobutnone = (RadioButton)v.findViewById(R.id.adofr_radiobutnone);

        adofr_srch_btn = (Button)v.findViewById(R.id.adofr_srch_btn);

        adofr_radiobutn.setChecked(true);
        adofr_radiobutnone.setChecked(false);

        adofr_radiobutn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(adofr_radiobutn.isChecked())
                {
                    adofr_radiobutn.setChecked(true);
                    adofr_radiobutnone.setChecked(false);
                }
            }
        });

        adofr_radiobutnone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(adofr_radiobutnone.isChecked())
                {
                    adofr_radiobutnone.setChecked(true);
                    adofr_radiobutn.setChecked(false);
                }
            }
        });

        assigndata();

    }

    public void assigndata(){

         components.CustomizeTextview(adofr_dscntype_edtx,Constants.Medium,R.color.serch_nrml_clr,getActivity().getApplicationContext().getResources().getString(R.string.dscunt_type),Constants.WrapLeftNormal+Constants.Roboto, new int[]{15,0,0,0});

        components.CustomizeTextview(adofr_ofrtpe_tx,Constants.Small,R.color.serch_nrml_clr,getActivity().getApplicationContext().getResources().getString(R.string.ofrtype),Constants.WrapLeftNormal+Constants.Roboto, new int[]{10,20,0,0});
        components.CustomizeTextview(adofr_publc_tx,Constants.Small,R.color.serch_nrml_clr,getActivity().getApplicationContext().getResources().getString(R.string.publc),Constants.WrapCenterNormal+Constants.Roboto, new int[]{0,0,0,0});
        components.CustomizeTextview(adofr_private_tx,Constants.Small,R.color.serch_nrml_clr,getActivity().getApplicationContext().getResources().getString(R.string.prvate),Constants.WrapCenterNormal+Constants.Roboto, new int[]{0,0,10,0});
        components.CustomizeTextview(adofr_brndnme_tx,Constants.XXNormal,R.color.sport_shoos_txt_clr,getActivity().getApplicationContext().getResources().getString(R.string.sprtshoe),Constants.WrapLeftNormal+Constants.Roboto, new int[]{0,0,0,0});
        components.CustomizeTextview(adofr_prce_tx,Constants.Normal,R.color.blue_color,getActivity().getApplicationContext().getResources().getString(R.string.prce_dolars),Constants.WrapLeftNormal+Constants.Roboto, new int[]{0,5,0,0});
        components.CustomizeTextview(adofr_brndprce_tx,Constants.Small,R.color.search_txt_clr,getActivity().getApplicationContext().getResources().getString(R.string.dolars_rate),Constants.WrapLeftNormal+Constants.Roboto, new int[]{0,7,0,0});
        components.CustomizeTextview(adofr_brndscunt_tx,Constants.Small,R.color.nrml_txt_clr,getActivity().getApplicationContext().getResources().getString(R.string.dscunt_ngtve),Constants.WrapLeftNormal+Constants.Roboto, new int[]{7,0,0,0});
        components.CustomizeTextview(adofr_ratngprcnt_tx,Constants.Small,R.color.nrml_txt_clr,getActivity().getApplicationContext().getResources().getString(R.string.ratng_cunt),Constants.WrapCenterNormal+Constants.Roboto, new int[]{7,-5,0,0});
        components.CustomizeTextview(adofr_strtdate_tx,Constants.XSmall,R.color.sport_shoos_txt_clr,getActivity().getApplicationContext().getResources().getString(R.string.start_date),Constants.WrapCenterNormal+Constants.Roboto, new int[]{5,5,0,5});
        components.CustomizeTextview(adofr_dsplydate_tx,Constants.XSmall,R.color.sport_shoos_txt_clr,getActivity().getApplicationContext().getResources().getString(R.string.disply_strtdate),Constants.WrapCenterNormal+Constants.Roboto, new int[]{5,5,20,5});
        components.CustomizeTextview(adofr_enddate_tx,Constants.XSmall,R.color.sport_shoos_txt_clr,getActivity().getApplicationContext().getResources().getString(R.string.end_date),Constants.WrapCenterNormal+Constants.Roboto, new int[]{5,5,0,5});
        components.CustomizeTextview(adofr_dsplyenddate_tx,Constants.XSmall,R.color.sport_shoos_txt_clr,getActivity().getApplicationContext().getResources().getString(R.string.disply_enddate),Constants.WrapCenterNormal+Constants.Roboto, new int[]{5,5,20,5});


        components.CustomizeImageviewBackground(adofr_slctctgry_img, new int[]{20,15}, R.drawable.dropdown_icon, new int[]{0,0,0,0});
        components.CustomizeImageviewBackground(adofr_slctsbctgry_img, new int[]{20,15}, R.drawable.dropdown_icon, new int[]{0,0,0,0});
        components.CustomizeImageviewBackground(adofr_prdct_img, new int[]{20,15}, R.drawable.dropdown_icon, new int[]{0,0,0,0});
        components.CustomizeImageview(adofr_catgry_img, new int[]{100,100}, R.drawable.restarunt_sammpleimg, new int[]{0,0,0,0});
        components.CustomizeImageviewBackground(adofr_dscntype_img, new int[]{20,15}, R.drawable.dropdown_icon, new int[]{0,0,0,0});
        components.CustomizeImageview(adofr_dsplydate_img, new int[]{14,16}, R.drawable.calender_icon, new int[]{0,0,5,0});
        components.CustomizeImageview(adofr_dsplyendate_img, new int[]{14,16}, R.drawable.calender_icon, new int[]{0,0,5,0});

        components.CustomizeButton(adofr_srch_btn, Constants.XXNormal,R.color.white,getActivity().getApplicationContext().getResources().getString(R.string.srch),R.drawable.list_bottom_bg,Constants.MatchCenterNormal+Constants.Roboto, new int[]{0,42}, new int[]{0,20,0,30});

        components.CustomizeEditview(adofr_prdct_edtx, Constants.Medium,R.color.serch_nrml_clr,R.color.serch_nrml_clr,getActivity().getApplicationContext().getResources().getString(R.string.srch_prdct),0,true,Constants.MatchLeftNormal+Constants.Roboto, new int[]{0,0,0,0});
        components.CustomizeEditview(adofr_slctctgry_edtx, Constants.Medium,R.color.serch_nrml_clr,R.color.serch_nrml_clr,getActivity().getApplicationContext().getResources().getString(R.string.seclt_catgry),0,true,Constants.MatchLeftNormal+Constants.Roboto, new int[]{0,0,0,0});
        components.CustomizeEditview(adofr_slctsbctgry_edtx, Constants.Medium,R.color.serch_nrml_clr,R.color.serch_nrml_clr,getActivity().getApplicationContext().getResources().getString(R.string.seclt_sub_catgry),0,true,Constants.MatchLeftNormal+Constants.Roboto, new int[]{0,0,0,0});

        adofr_dsplydate_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ShowDatePickerDialog(getActivity());
            }
        });


        adofr_dsplyendate_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ShowDatePickerDialog(getActivity());
            }
        });
    }

    public static class DatePickerFragment extends DialogFragment
            implements DatePickerDialog.OnDateSetListener {

        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            //Use the current date as the default date in the picker
            final Calendar c = Calendar.getInstance();
            int year = c.get(Calendar.YEAR);
            int month = c.get(Calendar.MONTH);
            int day = c.get(Calendar.DAY_OF_MONTH);

            //Create a new instance of DatePickerDialog and return it
            return new DatePickerDialog(getActivity(), this, year, month, day);
        }

        public void onDateSet(DatePicker view, int year, int month, int day) {
            // Do something with the date chosen by the user

            int MotnhVal=month+1;

            String monthval;

            if (MotnhVal<10){
                monthval="0"+MotnhVal+"/"+day+"/"+year;
            }else {
                monthval=+MotnhVal+"/"+day+"/"+year;
            }
            adofr_dsplydate_tx.setText(monthval);
            adofr_dsplyenddate_tx.setText(monthval);
        }
    }

    public void ShowDatePickerDialog(Activity activity) {
        DialogFragment newFragment = new DatePickerFragment();
        newFragment.show(getFragmentManager(),"datePicker");
    }

}
