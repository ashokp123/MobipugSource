package com.o3sa.mobipugapp.activities;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import com.o3sa.mobipugapp.R;
import com.o3sa.mobipugapp.uicomponents.BasicComponents;
import com.o3sa.mobipugapp.uicomponents.Constants;

/**
 * Created by Kiran on 20-10-2018.
 */

public class Signup extends Fragment {

    EditText cname_txt,cmobile_txt,cemail_txt,cpasswrd_txt,confrmpasswrd_txt;
    Button cregister_btn;
    RadioButton  regvendor_radbtn,regcustmr_radbtn;
    TextView regvendor_txt,regcustmr_txt;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.signup,container,false);
        intialization(v);
        return v;
    }

    public void intialization(View v){

        cname_txt =(EditText)v.findViewById(R.id.cname_txt);
        cmobile_txt= (EditText)v.findViewById(R.id.cmobile_txt);
        cemail_txt =(EditText)v.findViewById(R.id.cemail_txt);
        cpasswrd_txt= (EditText)v.findViewById(R.id.cpasswrd_txt);
        confrmpasswrd_txt =(EditText)v.findViewById(R.id.confrmpasswrd_txt);
        cregister_btn=(Button) v.findViewById(R.id.cregister_btn);
        regvendor_txt = (TextView)v.findViewById(R.id.regvendor_txt);
        regcustmr_txt = (TextView)v.findViewById(R.id.regcustmr_txt);

        regvendor_radbtn = (RadioButton)v.findViewById(R.id.regvendor_radbtn);
        regcustmr_radbtn = (RadioButton)v.findViewById(R.id.regcustmr_radbtn);

        regcustmr_radbtn.setChecked(true);
        regvendor_radbtn.setChecked(false);

        regvendor_radbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(regvendor_radbtn.isChecked())
                {
                    regvendor_radbtn.setChecked(true);
                    regcustmr_radbtn.setChecked(false);
                }
            }
        });

        regcustmr_radbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(regcustmr_radbtn.isChecked())
                {
                    regcustmr_radbtn.setChecked(true);
                    regvendor_radbtn.setChecked(false);
                }
            }
        });

        assigndata();

    }

    public void assigndata(){

        BasicComponents components = new BasicComponents(getActivity());

        components.CustomizeEditview(cname_txt, Constants.XNormal,R.color.gray1,R.color.lyt_grey,getActivity().getApplicationContext().getResources().getString(R.string.name),R.drawable.shadoweffect,true,Constants.MatchCenterNormal+Constants.Roboto, new int[]{0,20,0,0});
        components.CustomizeEditview(cmobile_txt,Constants.XNormal,R.color.gray1,R.color.lyt_grey,getActivity().getApplicationContext().getResources().getString(R.string.mobile),R.drawable.shadoweffect,true,Constants.MatchCenterNormal+Constants.Roboto, new int[]{0,15,0,0});
        components.CustomizeEditview(cemail_txt, Constants.XNormal,R.color.gray1,R.color.lyt_grey,getActivity().getApplicationContext().getResources().getString(R.string.email),R.drawable.shadoweffect,true,Constants.MatchCenterNormal+Constants.Roboto, new int[]{0,15,0,0});
        components.CustomizeEditview(cpasswrd_txt,Constants.XNormal,R.color.gray1,R.color.lyt_grey,getActivity().getApplicationContext().getResources().getString(R.string.paswrd),R.drawable.shadoweffect,true,Constants.MatchCenterNormal+Constants.Roboto, new int[]{0,15,0,0});
        components.SetPasswordHint(cpasswrd_txt);
        components.CustomizeEditview(confrmpasswrd_txt, Constants.XNormal,R.color.gray1,R.color.lyt_grey,getActivity().getApplicationContext().getResources().getString(R.string.confrmpassword),R.drawable.shadoweffect,true,Constants.MatchCenterNormal+Constants.Roboto, new int[]{0,15,0,0});
        components.SetPasswordHint(confrmpasswrd_txt);
        components.CustomizeButton(cregister_btn, Constants.Normal,R.color.white,getActivity().getApplicationContext().getResources().getString(R.string.register),R.drawable.cntinue_btn_bg,Constants.MatchCenterNormal+Constants.SFUIText, new int[]{0,45}, new int[]{0,20,0,0});

        components.CustomizeTextview(regcustmr_txt,Constants.Normal,R.color.sport_shoos_txt_clr,getActivity().getApplicationContext().getResources().getString(R.string.custmr),Constants.WrapCenterNormal+Constants.Roboto, new int[]{5,0,0,0});
        components.CustomizeTextview(regvendor_txt,Constants.Normal,R.color.sport_shoos_txt_clr,getActivity().getApplicationContext().getResources().getString(R.string.vendor),Constants.WrapCenterNormal+Constants.Roboto, new int[]{5,0,10,0});


    }

}
