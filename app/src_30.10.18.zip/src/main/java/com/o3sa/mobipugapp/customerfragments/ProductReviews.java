package com.o3sa.mobipugapp.customerfragments;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.TextView;

import com.o3sa.mobipugapp.R;
import com.o3sa.mobipugapp.database.Database;
import com.o3sa.mobipugapp.dumpdata.DumpData;
import com.o3sa.mobipugapp.dumpdata.StoredObjects;
import com.o3sa.mobipugapp.sidemenu.Sidemenu;
import com.o3sa.mobipugapp.uicomponents.BasicComponents;
import com.o3sa.mobipugapp.uicomponents.Constants;
import com.o3sa.mobipugapp.uicomponents.Customviewpager;
import com.o3sa.mobipugapp.uicomponents.RobotTextView;
import com.o3sa.mobipugapp.uicomponents.ViewpagerAdapter;

import java.util.ArrayList;

/**
 * Created by Kiran on 26-10-2018.
 */

public class ProductReviews extends Fragment {

    BasicComponents components;

    RatingBar prdct_rws_rating;
    TextView prdct_vw_dtls_txt,prdct_rw_rtng_txt,prdct_rw_rtng_txt1,prdct_ovrall_rws_txt;
    TextView prdct_five_star_txt,prdct_no_of_five_star_txt,prdct_four_star_txt,prdct_no_of_four_star_txt,prdct_three_star_txt,prdct_no_of_three_star_txt,
            prdct_two_star_txt,prdct_no_of_two_star_txt,prdct_one_star_txt,prdct_no_of_one_star_txt;
    ProgressBar prdct_five_star_rtngbar,prdct_four_star_rtngbar,prdct_three_star_rtngbar,prdct_two_star_rtngbar,prdct_one_star_rtngbar;
    Button prdct_wrt_rvw_nw_btn;
    LinearLayout prdct_rvw_lay;


    String [] names = {"15 mins ago","15 mins ago","15 mins ago"};

    int count=0;
    Database database;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.productreviews,container,false);

        database=new Database(getActivity());
        database.getAllDevice();
        components=new BasicComponents(getActivity());
        components.CustomizeTextview(Sidemenu.menu_title, Constants.XXLarge4,R.color.black,getActivity().getResources().getString(R.string.reviews),Constants.WrapLeftNormal+Constants.Roboto, new int[]{0,0,0,0});

        init(v);
        return v;
    }

    public void init(View b){

        prdct_vw_dtls_txt = (TextView)b.findViewById(R.id.prdct_vw_dtls_txt);
        prdct_rw_rtng_txt = (TextView)b.findViewById(R.id.prdct_rw_rtng_txt);
        prdct_rw_rtng_txt1 = (TextView)b.findViewById(R.id.prdct_rw_rtng_txt1);
        prdct_ovrall_rws_txt = (TextView)b.findViewById(R.id.prdct_ovrall_rws_txt);

        prdct_five_star_txt = (TextView)b.findViewById(R.id.prdct_five_star_txt);
        prdct_no_of_five_star_txt = (TextView)b.findViewById(R.id.prdct_no_of_five_star_txt);
        prdct_four_star_txt = (TextView)b.findViewById(R.id.prdct_four_star_txt);
        prdct_no_of_four_star_txt = (TextView) b.findViewById(R.id.prdct_no_of_four_star_txt);
        prdct_three_star_txt = (TextView)b.findViewById(R.id.prdct_three_star_txt);
        prdct_no_of_three_star_txt = (TextView)b.findViewById(R.id.prdct_no_of_three_star_txt);
        prdct_two_star_txt = (TextView)b.findViewById(R.id.prdct_two_star_txt);
        prdct_no_of_two_star_txt = (TextView)b.findViewById(R.id.prdct_no_of_two_star_txt);
        prdct_one_star_txt = (TextView)b.findViewById(R.id.prdct_one_star_txt);
        prdct_no_of_one_star_txt = (TextView)b.findViewById(R.id.prdct_no_of_one_star_txt);

        prdct_wrt_rvw_nw_btn = (Button)b.findViewById(R.id.prdct_wrt_rvw_nw_btn);
        prdct_rws_rating = (RatingBar)b.findViewById(R.id.prdct_rws_rating);

        prdct_five_star_rtngbar = (ProgressBar) b.findViewById(R.id.prdct_five_star_rtngbar);
        prdct_four_star_rtngbar = (ProgressBar)b.findViewById(R.id.prdct_four_star_rtngbar);
        prdct_three_star_rtngbar = (ProgressBar)b.findViewById(R.id.prdct_three_star_rtngbar);
        prdct_two_star_rtngbar = (ProgressBar)b.findViewById(R.id.prdct_two_star_rtngbar);
        prdct_one_star_rtngbar = (ProgressBar)b.findViewById(R.id.prdct_one_star_rtngbar);

        prdct_rvw_lay = (LinearLayout) b.findViewById(R.id.prdct_rvw_lay);

        StoredObjects.prdct_pg_list1.clear();
        for (int i = 0;i<names.length;i++){
            DumpData dumpData = new DumpData();
            dumpData.names = names[i];

            StoredObjects.prdct_pg_list1.add(dumpData);
        }
        prdct_rvw_lay.removeAllViews();
        for(int i =0;i<StoredObjects.prdct_pg_list1.size();i++){
            addlayout(prdct_rvw_lay,StoredObjects.prdct_pg_list1,i);
        }

        setData();

        prdct_wrt_rvw_nw_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AddReviewPopup(getActivity());
            }
        });

    }

    private void AddReviewPopup(Activity activity) {

        final Dialog dialog = new Dialog(activity);
        dialog.getWindow();
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.customerreview);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        TextView reviewtitle_tx = (TextView)dialog.findViewById(R.id.reviewtitle_tx);
       final TextView ratinggiven_txt = (TextView)dialog.findViewById(R.id.ratinggiven_txt);
        final RatingBar rws_rating = (RatingBar)dialog.findViewById(R.id.rws_rating);
        EditText customername_edtx=(EditText) dialog.findViewById(R.id.customername_edtx);
        EditText reviewtitle_edtx=(EditText) dialog.findViewById(R.id.reviewtitle_edtx);

        EditText customermsg_edtx=(EditText) dialog.findViewById(R.id.customermsg_edtx);
        Button addreview_btn=(Button) dialog.findViewById(R.id.addreview_btn);
        ImageView cancelrvw_btn = (ImageView)dialog.findViewById(R.id.cancelrvw_btn);

        components.CustomizeTextview(reviewtitle_tx,Constants.Large,R.color.txt_clr,getActivity().getResources().getString(R.string.addrvw),Constants.WrapCenterSemiBold+Constants.Roboto, new int[]{0,0,0,10});
        components.CustomizeTextview(ratinggiven_txt,Constants.XNormal,R.color.txt_clr,getActivity().getResources().getString(R.string.ratinggiven),Constants.MatchCenterNormal+Constants.Roboto, new int[]{0,0,0,0});
        components.CustomizeEditview(reviewtitle_edtx, Constants.Normal,R.color.black,R.color.pick_frm_clr,getActivity().getApplicationContext().getResources().getString(R.string.title),R.drawable.shadoweffect,true,Constants.MatchCenterNormal+Constants.Roboto, new int[]{10,6,10,6});
        components.CustomizeEditview(customername_edtx, Constants.Normal,R.color.black,R.color.pick_frm_clr,getActivity().getApplicationContext().getResources().getString(R.string.name),R.drawable.shadoweffect,true,Constants.MatchCenterNormal+Constants.Roboto, new int[]{10,6,10,6});
        components.CustomizeMultilineEditview(customermsg_edtx,Constants.Normal,R.color.black,R.color.pick_frm_clr,getActivity().getApplicationContext().getResources().getString(R.string.writeareview),R.drawable.shadoweffect,true,false,Constants.MatchLeftNormal+Constants.Roboto, new int[]{10,0,10,0},4);
        components.CustomizeButton(addreview_btn, Constants.XXNormal,R.color.white,getActivity().getApplicationContext().getResources().getString(R.string.submit),R.drawable.list_bottom_bg,Constants.MatchCenterBold+Constants.SFUIText, new int[]{0,42}, new int[]{10,20,10,30});
        rws_rating.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {

            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating,
                                        boolean fromUser) {
                // TODO Auto-generated method stub
                ratinggiven_txt.setText(""+ratingBar.getRating()+" OUT OF 5");
                //float rationgval=ratingBar.getRating();

            }
        });
        cancelrvw_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });



        dialog.show();

    }
    public void fragmentcalling( Fragment fragment){

        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.frame_container, fragment).commit();

    }
    public void addlayout(LinearLayout prdct_rvw_lay, ArrayList<DumpData> prdct_pg_list1, int position){

        View v = LayoutInflater.from(getActivity()).inflate(R.layout.prdct_vw_pager_lstitm,null);

        TextView prdct_good_at_txt = (TextView)v.findViewById(R.id.prdct_good_at_txt);
        TextView prdct_time_txt = (TextView)v.findViewById(R.id.prdct_time_txt);
        RatingBar prdct_lstitm_rating = (RatingBar) v.findViewById(R.id.prdct_lstitm_rating);

        TextView prdct_person_name_txt = (TextView)v.findViewById(R.id.prdct_person_name_txt);
        TextView prdct_descrptn_txt = (TextView)v.findViewById(R.id.prdct_descrptn_txt);

        components.CustomizeTextview(prdct_good_at_txt, Constants.Large,R.color.txt_clr,getActivity().getResources().getString(R.string.gud_p),Constants.WrapLeftNormal+Constants.Roboto, new int[]{12,20,0,0});
        components.CustomizeTextview(prdct_time_txt, Constants.Normal,R.color.rvw_txt_clr,prdct_pg_list1.get(position).names,Constants.WrapRightNormal+Constants.Roboto, new int[]{12,15,12,0});
        components.CustomizeTextview(prdct_person_name_txt, Constants.Normal,R.color.rvw_txt_clr,getActivity().getResources().getString(R.string.by_suuny),Constants.WrapLeftNormal+Constants.Roboto, new int[]{12,-5,12,0});
        components.CustomizeTextview(prdct_descrptn_txt, Constants.Normal,R.color.txt_clr,getActivity().getResources().getString(R.string.no_one),Constants.WrapLeftNormal+Constants.Roboto, new int[]{12,5,12,18});

        prdct_rvw_lay.addView(v);

    }

    private void setData() {

        components.CustomizeTextview(prdct_vw_dtls_txt,Constants.Large,R.color.txt_clr,getActivity().getResources().getString(R.string.rvw_nd_cmnts),Constants.WrapLeftNormal+Constants.Gibson, new int[]{12,12,0,0});
        components.CustomizeTextview(prdct_rw_rtng_txt,Constants.XXNormal,R.color.sport_shoos_txt_clr,getActivity().getResources().getString(R.string.three_zero),Constants.WrapLeftBold+Constants.Roboto, new int[]{15,0,0,0});
        components.CustomizeTextview(prdct_rw_rtng_txt1,Constants.Normal,R.color.nrml_txt_clr,getActivity().getResources().getString(R.string.of_five),Constants.WrapLeftNormal+Constants.Roboto, new int[]{3,3,0,0});


        components.CustomizeTextview(prdct_five_star_txt,Constants.Normal,R.color.nrml_txt_clr,getActivity().getResources().getString(R.string.five_s),Constants.WrapLeftNormal+Constants.Roboto, new int[]{3,0,0,0});
        components.CustomizeTextview(prdct_four_star_txt,Constants.Normal,R.color.nrml_txt_clr,getActivity().getResources().getString(R.string.four_s),Constants.WrapLeftNormal+Constants.Roboto, new int[]{3,0,0,0});
        components.CustomizeTextview(prdct_three_star_txt,Constants.Normal,R.color.nrml_txt_clr,getActivity().getResources().getString(R.string.three_s),Constants.WrapLeftNormal+Constants.Roboto, new int[]{3,0,0,0});
        components.CustomizeTextview(prdct_two_star_txt,Constants.Normal,R.color.nrml_txt_clr,getActivity().getResources().getString(R.string.two_s),Constants.WrapLeftNormal+Constants.Roboto, new int[]{3,0,0,0});
        components.CustomizeTextview(prdct_one_star_txt,Constants.Normal,R.color.nrml_txt_clr,getActivity().getResources().getString(R.string.one_s),Constants.WrapLeftNormal+Constants.Roboto, new int[]{3,0,0,0});

        components.CustomizeTextview(prdct_no_of_five_star_txt,Constants.Normal,R.color.nrml_txt_clr,getActivity().getResources().getString(R.string.seven_t),Constants.WrapLeftNormal+Constants.Roboto, new int[]{3,0,0,0});
        components.CustomizeTextview(prdct_no_of_four_star_txt,Constants.Normal,R.color.nrml_txt_clr,getActivity().getResources().getString(R.string.three_f),Constants.WrapLeftNormal+Constants.Roboto, new int[]{3,0,0,0});
        components.CustomizeTextview(prdct_no_of_three_star_txt,Constants.Normal,R.color.nrml_txt_clr,getActivity().getResources().getString(R.string.two_t),Constants.WrapLeftNormal+Constants.Roboto, new int[]{3,0,0,0});
        components.CustomizeTextview(prdct_no_of_two_star_txt,Constants.Normal,R.color.nrml_txt_clr,getActivity().getResources().getString(R.string.one_o),Constants.WrapLeftNormal+Constants.Roboto, new int[]{3,0,0,0});
        components.CustomizeTextview(prdct_no_of_one_star_txt,Constants.Normal,R.color.nrml_txt_clr,getActivity().getResources().getString(R.string.eight),Constants.WrapLeftNormal+Constants.Roboto, new int[]{3,0,0,0});
        components.CustomizeButton(prdct_wrt_rvw_nw_btn,Constants.Normal,R.color.blue_color,getActivity().getResources().getString(R.string.wrte_a),R.drawable.wrte_a_rvw_bg,Constants.MatchCenterNormal+Constants.Roboto, new int[]{0,47}, new int[]{25,0,25,0});


    }

}

