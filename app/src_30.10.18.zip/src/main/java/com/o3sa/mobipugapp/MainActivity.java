package com.o3sa.mobipugapp;

import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.TextView;

import com.o3sa.mobipugapp.dumpdata.StoredObjects;
import com.o3sa.mobipugapp.servicesparsing.JsonParsing;
import com.o3sa.mobipugapp.servicesparsing.WebServicesCalling;
import com.o3sa.mobipugapp.uicomponents.Constants;
import com.o3sa.mobipugapp.uicomponents.CustomRecyclerview;

import org.json.JSONException;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    public ArrayList<HashMap<String, String>> datalist;
    TextView parsingdata_txt;

    StoredObjects object;
    RecyclerView customrecyleview;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        intilization();

    }

    private void  intilization(){

        object= new StoredObjects(MainActivity.this);
        customrecyleview = (RecyclerView) findViewById(R.id.recyleview_list);

        StoredObjects.intilization();

        parsing_methods(0, "get_restaurants.php?", "lat=3.009998333333333&lng=101.09999833333335&page=1");

    }


    public void parsing_methods(final int val, String url, String parameters){

        WebServicesCalling webServicesCalling = new WebServicesCalling(MainActivity.this);

        webServicesCalling.calling_webservices(url,parameters,val);

        StoredObjects.Services_list.get(val).countDown = new CountDownTimer(60 * 1000, 1000) {
            public void onTick(long millisUntilFinished) {
                StoredObjects.LogMethod("Seconds remaining: "," Seconds remaining: " + millisUntilFinished / 100);

                if(StoredObjects.Services_list.get(0).Result != ""){

                    Log.i("Result",StoredObjects.Services_list.get(val).Result);
                    Log.i("Service_called",StoredObjects.Services_list.get(val).url);
                    try {

                        datalist = JsonParsing.GetJsonData(StoredObjects.Services_list.get(val).Result);

                        CustomRecyclerview recyclerview=new CustomRecyclerview(MainActivity.this);
                        //recyclerview.Assigndatatorecyleview(customrecyleview,datalist,"1", Constants.Listview,0, Constants.ver_orientation,R.layout.recylerviewlistitem);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    StoredObjects.Services_list.get(val).countDown.cancel();
                }

            }

            public void onFinish() {
                StoredObjects.LogMethod("Finished ","Finished");
            }

        };

        StoredObjects.Services_list.get(val).countDown.start();

    }

}
