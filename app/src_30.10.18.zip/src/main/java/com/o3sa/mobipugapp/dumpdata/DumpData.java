package com.o3sa.mobipugapp.dumpdata;

/**
 * Created by android_2 on 10/11/2018.
 */

public class DumpData {

    public String sbcat_nmslist,names,namess,address;
    public int prdct_pg_imgs,sbcat_imgslist,lndng_pg_imgs,hmpg_pg_imgs,catgrydetlsimglist,catgrydetlsgrdimglist,crteodrprfleimgs;
    public String ordernumbers,orderbrands,orderbrandprice;
    public String myodrsnums,myodrsdates,myodrscatgynme,myodrscatgryprce;
    public int myodrsprfleimgs,hmpg_ctgries_imgs,hmpg_keywords_imgs;

    public String prflecatgrylist,hmpg_ctgries_names,hmpg_keywords_names,hmpg_keywords_dscrptn,price,layout_highlight;
    public Integer ofrscatgryimglist;
    public String ofrsbrndlst;
    public String ofrsprmolst;
    public String ofrsendlst;
    public String ofrstartlst;
    public String ofrsdscntlst;
    public String bill_blood_txtvw;
    public String bill_dt_mn_one;
    public String bill_xray_txtvw;
    public String bill_dt_mn_two;

    public String cart_customerid,cart_proid,cart_proname,cart_proqty,cart_proimg,cart_proprice;
}
