package com.o3sa.mobipugapp.customerfragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.o3sa.mobipugapp.R;
import com.o3sa.mobipugapp.dumpdata.DumpData;
import com.o3sa.mobipugapp.dumpdata.StoredObjects;
import com.o3sa.mobipugapp.sidemenu.Sidemenu;
import com.o3sa.mobipugapp.uicomponents.BasicComponents;
import com.o3sa.mobipugapp.uicomponents.Constants;
import com.o3sa.mobipugapp.uicomponents.CustomRecyclerview;

import java.util.ArrayList;

/**
 * Created by Kiran on 26-10-2018.
 */

public class ReviewOrder extends Fragment {

    BasicComponents components;

    RecyclerView cart_rvw_order_rvw;
    TextView cart_rv_ordr_txt,cart_rv_ordr_no_of_itms_txt,cart_rv_ordr_dte_txt;
    TextView cart_rv_ordr_date_time_txt,cart_rv_ordr_dlvry_dte_txt,cart_rv_ordr_dlvry_dte_txt1;
    TextView cart_rv_ordr_price_txt,cart_rv_ordr_dlvry_time_txt,cart_rv_ordr_dlvry_time_txt1,cart_rv_ordr_dlvry_addrss_txt,cart_rv_ordr_dlvry_addrss_txt1;
    ImageView cart_rv_ordr_dlvry_dte_img,cart_rv_ordr_dlvry_dte_img1,cart_rv_ordr_dlvry_time_img,cart_rv_ordr_dlvry_time_img1;
    LinearLayout cart_rv_ordr_dlvry_addrss_lay;
    Button proceed_btn;

    String [] names = {"Product Name 1","Product Name 2"};
    String [] address = {"Block C, Level 6.13A, Scott Garden ( Kompleks Rimbun Scott ),289 Kothapet, Hyderabad.",
            "Block C, Level 6.13A, Scott Garden ( Kompleks Rimbun Scott ),289 Kothapet, Hyderabad."};

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.review_order,container,false);

        components = new BasicComponents(getActivity());
        components.CustomizeTextview(Sidemenu.menu_title, Constants.XXLarge4,R.color.black,getActivity().getResources().getString(R.string.revieworder),Constants.WrapLeftNormal+Constants.Roboto, new int[]{0,0,0,0});

        init(v);
        return v;

    }

    public void init(View b){

        cart_rvw_order_rvw = (RecyclerView)b.findViewById(R.id.cart_rvw_order_rvw);

        cart_rv_ordr_txt = (TextView)b.findViewById(R.id.cart_rv_ordr_txt);
        cart_rv_ordr_no_of_itms_txt = (TextView)b.findViewById(R.id.cart_rv_ordr_no_of_itms_txt);
        cart_rv_ordr_dte_txt = (TextView)b.findViewById(R.id.cart_rv_ordr_dte_txt);
        cart_rv_ordr_date_time_txt = (TextView)b.findViewById(R.id.cart_rv_ordr_date_time_txt);
        cart_rv_ordr_dlvry_dte_txt = (TextView)b.findViewById(R.id.cart_rv_ordr_dlvry_dte_txt);
        cart_rv_ordr_dlvry_dte_txt1 = (TextView)b.findViewById(R.id.cart_rv_ordr_dlvry_dte_txt1);
        cart_rv_ordr_dlvry_time_txt = (TextView)b.findViewById(R.id.cart_rv_ordr_dlvry_time_txt);
        cart_rv_ordr_dlvry_time_txt1 = (TextView)b.findViewById(R.id.cart_rv_ordr_dlvry_time_txt1);

        cart_rv_ordr_dlvry_addrss_txt = (TextView)b.findViewById(R.id.cart_rv_ordr_dlvry_addrss_txt);
        cart_rv_ordr_dlvry_addrss_txt1 = (TextView)b.findViewById(R.id.cart_rv_ordr_dlvry_addrss_txt1);

        cart_rv_ordr_dlvry_dte_img = (ImageView) b.findViewById(R.id.cart_rv_ordr_dlvry_dte_img);
        cart_rv_ordr_dlvry_dte_img1 = (ImageView)b.findViewById(R.id.cart_rv_ordr_dlvry_dte_img1);
        cart_rv_ordr_dlvry_time_img = (ImageView)b.findViewById(R.id.cart_rv_ordr_dlvry_time_img);
        cart_rv_ordr_dlvry_time_img1 = (ImageView)b.findViewById(R.id.cart_rv_ordr_dlvry_time_img1);
        cart_rv_ordr_price_txt = (TextView) b.findViewById(R.id.cart_rv_ordr_price_txt);

        cart_rv_ordr_dlvry_addrss_lay = (LinearLayout) b.findViewById(R.id.cart_rv_ordr_dlvry_addrss_lay);

        proceed_btn=(Button) b.findViewById(R.id.proceed_btn);

        StoredObjects.cart_rv_ordr_list.clear();
        for (int i = 0;i<names.length;i++){
            DumpData dumpData = new DumpData();
            dumpData.namess = names[i];

            StoredObjects.cart_rv_ordr_list.add(dumpData);
        }

        CustomRecyclerview recyclerview = new CustomRecyclerview(getActivity());
        recyclerview.Assigndatatorecyleview(cart_rvw_order_rvw, StoredObjects.cart_rv_ordr_list,"cart_rv_ordr_rvw",
                Constants.Listview,0, Constants.ver_orientation,R.layout.cart_rv_ordr_lstitm);

        StoredObjects.cart_rv_ordr_list1.clear();
        for (int i = 0;i<address.length;i++){
            DumpData dumpData = new DumpData();
            dumpData.address = address[i];

            StoredObjects.cart_rv_ordr_list1.add(dumpData);
        }

        cart_rv_ordr_dlvry_addrss_lay.removeAllViews();
        for(int i=0;i<StoredObjects.cart_rv_ordr_list1.size();i++){
            addlayout(cart_rv_ordr_dlvry_addrss_lay,StoredObjects.cart_rv_ordr_list1,i);
        }

        setData();

    }

    private void setData(){

        components.CustomizeImageview(cart_rv_ordr_dlvry_dte_img, new int[]{10,10}, R.drawable.up_and_down, new int[]{0,0,0,0});
        components.CustomizeImageview(cart_rv_ordr_dlvry_time_img, new int[]{10,10}, R.drawable.up_and_down, new int[]{0,0,0,0});

        components.CustomizeTextview(cart_rv_ordr_txt, Constants.XXNormal,R.color.rvw_txt_clr,getActivity().getApplicationContext().getResources().getString(R.string.rv_ordr),Constants.WrapLeftNormal+Constants.Roboto, new int[]{0,0,0,0});
        components.CustomizeTextview(cart_rv_ordr_dte_txt, Constants.XNormal,R.color.sport_shoos_txt_clr,getActivity().getApplicationContext().getResources().getString(R.string.day),Constants.WrapLeftBold+Constants.Roboto, new int[]{0,0,0,0});
        components.CustomizeTextview(cart_rv_ordr_no_of_itms_txt, Constants.Medium,R.color.rvw_txt_clr,getActivity().getApplicationContext().getResources().getString(R.string.two_i),Constants.WrapLeftNormal+Constants.Roboto, new int[]{0,0,0,0});

        components.CustomizeTextview(cart_rv_ordr_date_time_txt, Constants.XNormal,R.color.sport_shoos_txt_clr,getActivity().getApplicationContext().getResources().getString(R.string.dlvry_d),Constants.WrapLeftBold+Constants.Roboto, new int[]{0,8,0,0});
        components.CustomizeTextview(cart_rv_ordr_dlvry_dte_txt, Constants.XNormal,R.color.rvw_txt_clr,getActivity().getApplicationContext().getResources().getString(R.string.dlvry_dt),Constants.WrapLeftNormal+Constants.Roboto, new int[]{0,4,0,0});
        components.CustomizeTextview(cart_rv_ordr_dlvry_dte_txt1, Constants.Medium,R.color.txt_clr,getActivity().getApplicationContext().getResources().getString(R.string.selct),Constants.WrapLeftNormal+Constants.Roboto, new int[]{12,7,7,7});

        components.CustomizeTextview(cart_rv_ordr_dlvry_time_txt, Constants.XNormal,R.color.rvw_txt_clr,getActivity().getApplicationContext().getResources().getString(R.string.dlvry_t),Constants.WrapLeftNormal+Constants.Roboto, new int[]{0,13,0,0});
        components.CustomizeTextview(cart_rv_ordr_dlvry_time_txt1, Constants.Medium,R.color.txt_clr,getActivity().getApplicationContext().getResources().getString(R.string.selct_t),Constants.WrapLeftNormal+Constants.Roboto, new int[]{12,7,7,7});

        components.CustomizeTextview(cart_rv_ordr_dlvry_addrss_txt, Constants.XNormal,R.color.sport_shoos_txt_clr,getActivity().getApplicationContext().getResources().getString(R.string.dlvry_adrs),Constants.WrapLeftBold+Constants.Roboto, new int[]{0,0,0,0});
        components.CustomizeTextview(cart_rv_ordr_dlvry_addrss_txt1, Constants.XNormal,R.color.rvw_txt_clr,getActivity().getApplicationContext().getResources().getString(R.string.dlvry_adrs),Constants.WrapLeftNormal+Constants.Roboto, new int[]{12,10,0,0});

        components.CustomizeButton(proceed_btn,Constants.XNormal,R.color.white,getActivity().getResources().getString(R.string.proceedtopay), R.drawable.addtocart_bg, Constants.MatchCenterNormal+Constants.SFUIText, new int[]{0,50}, new int[]{10,10,10,5});
        components.CustomizeTextview(cart_rv_ordr_price_txt, Constants.Medium,R.color.sport_shoos_txt_clr,getActivity().getApplicationContext().getResources().getString(R.string.pric),Constants.WrapLeftNormal+Constants.Roboto, new int[]{15,0,0,0});


    }

    public void addlayout(LinearLayout layout, final ArrayList<DumpData> cart_rv_ordr_list1, int position){
        View v	=LayoutInflater.from(getActivity()).inflate(R.layout.cart_rv_ordr_adrs_lstitm, null);

        ImageView cartrevieworder_img = (ImageView) v.findViewById(R.id.cartrevieworder_img);
        TextView cartrevieworder_text=(TextView) v.findViewById(R.id.cartrevieworder_text);

        View top_vw = (View)v.findViewById(R.id.top_vw);

        if(position==0){
            components.CustomizeImageview(cartrevieworder_img, new int[]{15,15}, R.drawable.blacknewtwo, new int[]{0,6,0,0});

        }else{
            components.CustomizeImageview(cartrevieworder_img, new int[]{15,15}, R.drawable.blacknewone, new int[]{0,6,0,0});

        }
        components.CustomizeTextview(cartrevieworder_text, Constants.Medium,R.color.sport_shoos_txt_clr,cart_rv_ordr_list1.get(position).address,Constants.WrapLeftNormal+Constants.Roboto, new int[]{3,0,0,0});

        if (position==0){
            top_vw.setVisibility(View.GONE);
        }else{
            top_vw.setVisibility(View.VISIBLE);
        }

        layout.addView(v);

    }

}

