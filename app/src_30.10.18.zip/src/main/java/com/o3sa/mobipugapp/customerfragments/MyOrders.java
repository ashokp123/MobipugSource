package com.o3sa.mobipugapp.customerfragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.o3sa.mobipugapp.R;
import com.o3sa.mobipugapp.dumpdata.DumpData;
import com.o3sa.mobipugapp.dumpdata.StoredObjects;
import com.o3sa.mobipugapp.uicomponents.BasicComponents;
import com.o3sa.mobipugapp.uicomponents.Constants;
import com.o3sa.mobipugapp.uicomponents.CustomRecyclerview;

/**
 * Created by android_2 on 10/12/2018.
 */

public class MyOrders extends Fragment {

    RecyclerView myodrs_recycleviwe;
    BasicComponents components;

    String[] myodrs_billno  = {"#568123","#568123","#568123","#568123","#568123"};
    Integer[] myodrs_catgryimgs  = {R.drawable.ic_launcher,R.drawable.ic_launcher,R.drawable.ic_launcher,
                                    R.drawable.ic_launcher, R.drawable.ic_launcher};
    String[] myodrs_bookdate = {"Booked on Oct 1,2018","Booked on Oct 1,2018","Booked on Oct 1,2018","Booked on Oct 1,2018","Booked on Oct 1,2018"};
    String[] myodrs_catgrynme = {"Sports shoes","Sports shoes","Sports shoes","Sports shoes","Sports shoes"};

    String[] myodrs_catgryprice = {"$1,450.00","$1,450.00","$1,450.00","$1,450.00","$1,450.00"};


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.myorders,container,false);

        components=new BasicComponents(getActivity());
        intialization(v);
        return v;
    }

    public void intialization(View v){

        myodrs_recycleviwe = (RecyclerView)v.findViewById(R.id.myodrs_recycleviwe);


        StoredObjects.myordersarraylist.clear();

        for (int i = 0;i<myodrs_billno.length;i++){
            DumpData dumpData = new DumpData();
            dumpData.myodrsnums = myodrs_billno[i];
            dumpData.myodrsdates = myodrs_bookdate[i];
            dumpData.myodrsprfleimgs= myodrs_catgryimgs[i];
            dumpData.myodrscatgynme = myodrs_catgrynme[i];
            dumpData.myodrscatgryprce = myodrs_catgryprice[i];

            StoredObjects.myordersarraylist.add(dumpData);
        }

        CustomRecyclerview recyclerview = new CustomRecyclerview(getActivity());
        recyclerview.Assigndatatorecyleview(myodrs_recycleviwe,StoredObjects.myordersarraylist,"myorders", Constants.Listview,0,Constants.ver_orientation,R.layout.myorders_listitems);

    }
}
