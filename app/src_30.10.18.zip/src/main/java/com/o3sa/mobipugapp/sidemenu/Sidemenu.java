package com.o3sa.mobipugapp.sidemenu;

import android.annotation.TargetApi;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.o3sa.mobipugapp.R;
import com.o3sa.mobipugapp.activities.LandingPage;
import com.o3sa.mobipugapp.customerfragments.CustomerProductlist;
import com.o3sa.mobipugapp.customerfragments.MyOrders;
import com.o3sa.mobipugapp.customerfragments.Mycart;
import com.o3sa.mobipugapp.customerfragments.OrdersMain;
import com.o3sa.mobipugapp.dumpdata.StoredObjects;
import com.o3sa.mobipugapp.fragments.AboutUs;
import com.o3sa.mobipugapp.fragments.GenerateBill;
import com.o3sa.mobipugapp.customerfragments.HomePage;
import com.o3sa.mobipugapp.fragments.ManageCategoriesMain;
import com.o3sa.mobipugapp.fragments.ManageOffers;
import com.o3sa.mobipugapp.fragments.ManageOffersMain;
import com.o3sa.mobipugapp.fragments.ManageProductsMain;
import com.o3sa.mobipugapp.fragments.Profile;
import com.o3sa.mobipugapp.fragments.VendorHomePage;
import com.o3sa.mobipugapp.uicomponents.BasicComponents;
import com.o3sa.mobipugapp.uicomponents.Constants;

import java.util.ArrayList;

/**
 * Created by android-4 on 09/26/2018.
 */

public class Sidemenu extends AppCompatActivity {

    public static DrawerLayout mDrawerLayout;
    public static ListView mDrawerList;
    private ActionBarDrawerToggle mDrawerToggle;

    private CharSequence mDrawerTitle;

    private String[] navMenuTitles;
    private TypedArray navMenuIconsleft;
    private TypedArray navMenuIconsright;
    private ArrayList<NavDrawerItems> navDrawerItems;
    private NavDrawerListAdapter adapter;
    public static int drawablecount = 0;

    //actionbar

    //hedr part
    ViewGroup header;
    public static LinearLayout view_profile_sidemenu;
    public static LinearLayout headr_cancl_lay,hedr_prfl_img_lay;
    public static ImageView headr_cancl_img,headr_profile_img;
    public static TextView hedr_prfl_ratng_txt,hedr_prfl_name_txt,hedr_prfl_mail_txt;

    ImageView menu_img,menu_share_img,menu_cart_img;
    public static TextView menu_title;
    BasicComponents components;
    @TargetApi(Build.VERSION_CODES.ICE_CREAM_SANDWICH)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.side_menu);

        components = new BasicComponents(Sidemenu.this);
        initialization();
        if (savedInstanceState == null) {
            //on first time display view for first nav item
            if( StoredObjects.UserType.equalsIgnoreCase("Vendor")){
                menu_cart_img.setVisibility(View.GONE);
                fragmentcallinglay(new VendorHomePage());
            }else{
                menu_cart_img.setVisibility(View.VISIBLE);
                fragmentcallinglay(new HomePage());
            }


            displayView(0);
        }

    }

    private void initialization() {

        mDrawerList = (ListView) findViewById(R.id.mDrawerList);
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);

        //Actionbar
        menu_share_img=(ImageView) findViewById(R.id.menu_share_img);
        menu_img=(ImageView) findViewById(R.id.menu_img);
        menu_cart_img=(ImageView) findViewById(R.id.menu_cart_img);
        menu_title=(TextView) findViewById(R.id.menu_title);
        navDrawerItems = new ArrayList<NavDrawerItems>();
        if( StoredObjects.UserType.equalsIgnoreCase("Vendor")){
            navMenuTitles = getResources().getStringArray(R.array.vendormenu_list);
            navMenuIconsleft = getResources().obtainTypedArray(R.array.vendormenu_icons);
        }else{
            navMenuTitles = getResources().getStringArray(R.array.customermenu_list);
            navMenuIconsleft = getResources().obtainTypedArray(R.array.customermenu_icons);
        }


        for (int i = 0; i < navMenuTitles.length; i++) {
            navDrawerItems.add(new NavDrawerItems(navMenuTitles[i], navMenuIconsleft.getResourceId(i, -1)));
        }
        navMenuIconsleft.recycle();
        mDrawerList.setOnItemClickListener(new SlideMenuClickListener());

        menu_img.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                drawablecount++;
                if (drawablecount == 1) {
                    mDrawerLayout.openDrawer(mDrawerList);
                    //title.setText(mTitle);
                } else {
                    drawablecount = 0;
                    mDrawerLayout.closeDrawer(mDrawerList);

                }

            }

        });

        adapter = new NavDrawerListAdapter(Sidemenu.this, navDrawerItems);
        header =(ViewGroup) LayoutInflater.from(this).inflate(R.layout.menu_header, null);

        view_profile_sidemenu = (LinearLayout) header.findViewById(R.id.view_profile_sidemenu);

        headr_cancl_img=(ImageView) header.findViewById(R.id.headr_cancl_img);
        headr_profile_img=(ImageView) header.findViewById(R.id.headr_profile_img);
        headr_cancl_lay =(LinearLayout)  header.findViewById(R.id.headr_cancl_lay);
        hedr_prfl_img_lay =(LinearLayout) header.findViewById(R.id.hedr_prfl_img_lay);
        hedr_prfl_ratng_txt =(TextView) header.findViewById(R.id.hedr_prfl_ratng_txt);
        hedr_prfl_name_txt =(TextView)  header.findViewById(R.id.hedr_prfl_name_txt);
        hedr_prfl_mail_txt = (TextView) header.findViewById(R.id.hedr_prfl_mail_txt);

        view_profile_sidemenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        mDrawerList.addHeaderView(header, null, false);

        mDrawerList.setAdapter(adapter);
        adapter.notifyDataSetChanged();

        mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout,
                R.drawable.ic_launcher, //nav menu toggle icon
                R.string.app_name, // nav drawer open - description for accessibility
                R.string.app_name // nav drawer close - description for accessibility
        ) {
            public void onDrawerClosed(View view) {
                //getActionBar().setTitle(mTitle);
                //title.setText(mTitle);
                invalidateOptionsMenu();
                drawablecount = 0;

                Log.i("test", "drawablelayout closed");

            }

            public void onDrawerOpened(View drawerView) {
                //getActionBar().setTitle(mDrawerTitle);
                drawablecount++;
                Log.i("test", "drawablelayout opened");
                invalidateOptionsMenu();
            }

        };
        mDrawerLayout.setDrawerListener(mDrawerToggle);

        menu_share_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = "Mobipug";
                Intent sharingIntent = new Intent(Intent.ACTION_SEND);
                sharingIntent.setType("text/plain");
                sharingIntent.putExtra(Intent.EXTRA_SUBJECT, "Mobipug");
                sharingIntent.putExtra(Intent.EXTRA_TEXT, name +" Please refer to the given link "+"https://play.google.com/store/");
                startActivity(Intent.createChooser(sharingIntent, "Share via"));
            }
        });


        menu_cart_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragmentcallinglay(new OrdersMain());
            }
        });

        AssignData();

    }

    private class SlideMenuClickListener implements ListView.OnItemClickListener {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long arg3) {

            displayView(position);

        }
    }

    public void displayView(int position) {
        Fragment fragment = null;

        position -= mDrawerList.getHeaderViewsCount();
        StoredObjects.count= position;

        if( StoredObjects.UserType.equalsIgnoreCase("Vendor")){
            switch (position) {
                case 0:
                    fragment = new VendorHomePage();
                    break;

                case 1:
                    fragment = new ManageProductsMain();
                    break;

                case 2:
                    fragment = new ManageOffersMain();
                    break;

                case 3:
                    fragment = new ManageCategoriesMain();
                    break;

                case 4:
                    fragment = new GenerateBill();
                    break;


                case 5:
                   // fragment = new AboutUs();
                    break;
                case 6:
                    fragment = new AboutUs();
                    break;
                case 7:
                    fragment = new AboutUs();
                    break;
                case 8:
                    //fragment = new Testing();
                    break;


                case 9:
                    DisplayAlertDialogg("Do you want to Logout?");
                    break;

            }

        }else{
            switch (position) {
                case 0:
                    fragment = new HomePage();
                    break;

                case 1:
                    fragment = new CustomerProductlist();
                    break;

                case 2:
                    fragment = new MyOrders();
                    break;

                case 3:
                    fragment = new Profile();
                    break;

                case 4:
                    //fragment = new Testing();
                    break;

                case 5:
                    fragment = new AboutUs();
                    break;

                case 6:
                    fragment = new AboutUs();
                    break;

                case 7:
                   // fragment = new AboutUs();
                    break;

                case 8:
                    DisplayAlertDialogg("Do you want to Logout?");
                    break;



            }

        }


        if (fragment != null) {
            FragmentManager fragmentManager = getSupportFragmentManager();
            fragmentManager.beginTransaction().replace(R.id.frame_container, fragment).commit();

            //update selected item and title, then close the drawer
            mDrawerList.setItemChecked(position, true);
            mDrawerList.setSelection(position);
            setTitle(navMenuTitles[position]);
            mDrawerLayout.closeDrawer(mDrawerList);
            components.CustomizeTextview(menu_title, Constants.XXLarge4,R.color.black,navMenuTitles[position],Constants.WrapLeftNormal+Constants.Roboto, new int[]{0,0,0,0});

        } else {
            //error in creating fragment
            Log.e("MainActivity", "Error in creating fragment");
        }

    }

    public void AssignData(){



        components.CustomizeImageview(headr_profile_img, new int[]{55,65},R.drawable.ic_launcher, new int[]{0,0,0,0});
        components.CustomizeImageview(headr_cancl_img, new int[]{20,20}, R.drawable.ic_launcher, new int[]{0,12,0,5});
        components.CustomizeTextview(hedr_prfl_ratng_txt, Constants.Small,R.color.white,getApplicationContext().getResources().getString(R.string.four),Constants.WrapCenterNormal+Constants.Gibson, new int[]{0,0,0,0});
        components.CustomizeTextview(hedr_prfl_name_txt, Constants.XLarge,R.color.white,getApplicationContext().getResources().getString(R.string.arel),Constants.WrapLeftNormal+Constants.Gibson, new int[]{0,12,0,0});
        components.CustomizeTextview(hedr_prfl_mail_txt, Constants.Normal,R.color.side_memu_nrml_txt_clr,getApplicationContext().getResources().getString(R.string.arel_mail),Constants.WrapLeftNormal+Constants.Gibson, new int[]{0,5,0,15});
        components.CustomizeImageview(menu_share_img, new int[]{22,24},R.drawable.shareimage, new int[]{0,0,10,0});
        components.CustomizeImageview(menu_img, new int[]{32,28},R.drawable.menu_icon, new int[]{5,0,0,0});

        components.CustomizeTextview(menu_title, Constants.XXLarge4,R.color.black,navMenuTitles[0],Constants.WrapLeftNormal+Constants.Roboto, new int[]{0,0,0,0});

    }

    public void fragmentcallinglay(Fragment fragment) {

        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.frame_container, fragment).commit();

    }

    public  void fragmentcalling(Fragment fragment, String type){

        android.support.v4.app.FragmentManager fragmentManager = getSupportFragmentManager();
        android.support.v4.app.FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame_container, fragment);

        if(type.equalsIgnoreCase("0")){

        }else{
            fragmentTransaction.addToBackStack("my_fragment");
        }

        fragmentTransaction.commit();

    }


    public void setTitle(CharSequence title) {
        //mTitle = title;
        //getActionBar().setTitle(mTitle);
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        // Sync the toggle state after onRestoreInstanceState has occurred.
        mDrawerToggle.syncState();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        // Pass any configuration change to the drawer toggls
        mDrawerToggle.onConfigurationChanged(newConfig);
    }


    public void onBackPressed() {
        if (getSupportFragmentManager().getBackStackEntryCount() > 1) {
            getSupportFragmentManager().popBackStack();
        }
        else if(getSupportFragmentManager().getBackStackEntryCount() == 0||getSupportFragmentManager().getBackStackEntryCount() == 1) {

            checkbackclick();
        }
        else {
            super.onBackPressed();
        }
    }

    boolean doubleBackToExitPressedOnce = false;
    public void checkbackclick() {

        if (doubleBackToExitPressedOnce) {
            // super.onBackPressed();
            DisplayAlertDialog("Do You Want To Exit?");
            return;
        }
        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce=false;
            }
        }, 3000);
    }

    public void DisplayAlertDialog(String string) {

        AlertDialog.Builder builder = new AlertDialog.Builder(Sidemenu.this);

        builder.setMessage(string)
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                       minimizeApp();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }

    public void minimizeApp() {
        Intent startMain = new Intent(Intent.ACTION_MAIN);
        startMain.addCategory(Intent.CATEGORY_HOME);
        startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(startMain);
    }

    public void DisplayAlertDialogg(String string) {
        AlertDialog.Builder builder = new AlertDialog.Builder(Sidemenu.this);

        builder.setMessage(string)
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        Sidemenu.this.finish();
                        startActivity(new Intent(Sidemenu.this,LandingPage.class));

                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();
                    }
                });

        AlertDialog alert = builder.create();
        alert.show();
    }

}