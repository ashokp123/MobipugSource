package com.o3sa.mobipugapp.fragments;

import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import com.o3sa.mobipugapp.R;
import com.o3sa.mobipugapp.dumpdata.DumpData;
import com.o3sa.mobipugapp.dumpdata.StoredObjects;
import com.o3sa.mobipugapp.uicomponents.BasicComponents;
import com.o3sa.mobipugapp.uicomponents.Constants;
import com.o3sa.mobipugapp.uicomponents.CustomRecyclerview;

/**
 * Created by android_2 on 10/13/2018.
 */

public class OffersList extends Fragment {

    TextView ofrs_filtrs_tx;
    EditText ofrs_srch_tx;
    ImageView ofrs_menu_img,ofrs_filtr_img;
    RecyclerView ofrs_recycleviwe;
    BasicComponents components;
    private PopupWindow mPopupWindow;
    Integer[] ofrs_catgryimgs = {R.drawable.restarunt_sammpleimg,R.drawable.restarunt_sammpleimg,R.drawable.restarunt_sammpleimg,R.drawable.restarunt_sammpleimg,R.drawable.restarunt_sammpleimg};
    String[] ofrs_brndtxt = {"Sport Shoes","Sport Shoes","Sport Shoes","Sport Shoes","Sport Shoes"};
    String[] ofrs_promotxt = {"Abc123","Abc123","Abc123","Abc123","Abc123"};
    String[] ofrs_starttxt = {"10-10-2018","10-10-2018","10-10-2018","10-10-2018","10-10-2018"};
    String[] ofrs_endtxt   =   {"15-10-2018","15-10-2018","15-10-2018","15-10-2018","15-10-2018"};
    String[] ofrs_discnttxt = {"50% OFF","50% OFF","50% OFF","50% OFF","50% OFF"};
    LinearLayout prdct_lst_fltr_lay;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.offerslist,container,false);
        components=new BasicComponents(getActivity());

        intialization(v);
        assigndata();
        return v;
    }

    public void intialization(View v){
        prdct_lst_fltr_lay = (LinearLayout)v.findViewById(R.id.prdct_lst_fltr_lay);
        ofrs_menu_img = (ImageView)v.findViewById(R.id.ofrs_menu_img);
        ofrs_filtr_img = (ImageView)v.findViewById(R.id.ofrs_filtr_img);
        ofrs_srch_tx = (EditText) v.findViewById(R.id.ofrs_srch_tx);
        ofrs_filtrs_tx =(TextView)v.findViewById(R.id.ofrs_filtrs_tx);

        ofrs_recycleviwe = (RecyclerView)v.findViewById(R.id.ofrs_recycleviwe);

        StoredObjects.offersarraylist.clear();

        for (int i = 0;i<ofrs_catgryimgs.length;i++){
            DumpData dumpData = new DumpData();
            dumpData.ofrscatgryimglist = ofrs_catgryimgs[i];
            dumpData.ofrsbrndlst = ofrs_brndtxt[i];
            dumpData.ofrsprmolst = ofrs_promotxt[i];
            dumpData.ofrstartlst= ofrs_starttxt[i];
            dumpData.ofrsendlst = ofrs_endtxt[i];
            dumpData.ofrsdscntlst = ofrs_discnttxt[i];

            StoredObjects.offersarraylist.add(dumpData);
        }

        CustomRecyclerview recyclerview = new CustomRecyclerview(getActivity());
        recyclerview.Assigndatatorecyleview(ofrs_recycleviwe,StoredObjects.offersarraylist,"offerslist",
                                            Constants.Listview, 0, Constants.ver_orientation,R.layout.offers_listitems);

    }

    public void assigndata(){

        components.CustomizeImageview(ofrs_menu_img, new int[]{20,20}, R.drawable.pink_searchicon, new int[]{0,0,0,0});
        components.CustomizeImageview(ofrs_filtr_img, new int[]{20,20}, R.drawable.filter_icon_new, new int[]{0,0,0,0});
        components.CustomizeEditview(ofrs_srch_tx, Constants.Medium,R.color.thik_grey,R.color.thik_grey,getActivity().getApplicationContext().getResources().getString(R.string.search),0,true,Constants.MatchLeftNormal+Constants.Roboto, new int[]{0,0,0,0});
        components.CustomizeTextview(ofrs_filtrs_tx, Constants.Normal,R.color.sport_shoos_txt_clr,getActivity().getApplicationContext().getResources().getString(R.string.filtrs),Constants.WrapCenterNormal+Constants.Roboto, new int[]{10,0,0,0});
        prdct_lst_fltr_lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Offersfilterpopup(prdct_lst_fltr_lay);
            }
        });
    }

    private void Offersfilterpopup(LinearLayout viewpager_lay){

        LayoutInflater mLayoutInflater=LayoutInflater.from(getActivity());

        View mView=mLayoutInflater.inflate(R.layout.offersfilterpopup, null);

        mPopupWindow=new PopupWindow(mView, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, true);
        mPopupWindow.setContentView(mView);


        ImageView mange_uparow_img = (ImageView)mView.findViewById(R.id.mange_uparow_img);

        LinearLayout select_ctgry_lay = (LinearLayout)mView.findViewById(R.id.select_ctgry_lay);
        LinearLayout select_subctgry_lay = (LinearLayout)mView.findViewById(R.id.select_subctgry_lay);
        LinearLayout select_discount_lay = (LinearLayout)mView.findViewById(R.id.select_discount_lay);
        LinearLayout select_ofrstatus_lay = (LinearLayout)mView.findViewById(R.id.select_ofrstatus_lay);

        EditText subctgry_edtx = (EditText)mView.findViewById(R.id.subctgry_edtx);
        EditText ctgry_edtx = (EditText)mView.findViewById(R.id.ctgry_edtx);
        EditText discount_edtx = (EditText)mView.findViewById(R.id.discount_edtx);
        EditText seloffer_edtx = (EditText)mView.findViewById(R.id.seloffer_edtx);
        EditText adofr_dsplydate_et = (EditText)mView.findViewById(R.id.adofr_dsplydate_et);
        EditText adofr_dsplyenddate_et = (EditText)mView.findViewById(R.id.adofr_dsplyenddate_et);

        TextView adofr_strtdate_tx = (TextView)mView.findViewById(R.id.adofr_strtdate_tx);
        TextView adofr_enddate_tx = (TextView)mView.findViewById(R.id.adofr_enddate_tx);
        Button filter_done_btn = (Button)mView.findViewById(R.id.filter_done_btn);
        ImageView adofr_dsplydate_img = (ImageView)mView.findViewById(R.id.adofr_dsplydate_img);
        ImageView adofr_dsplyendate_img = (ImageView)mView.findViewById(R.id.adofr_dsplyendate_img);

        components.CustomizeEditview(subctgry_edtx, Constants.Medium,R.color.thik_grey,R.color.thik_grey,getActivity().getApplicationContext().getResources().getString(R.string.sel_subcategory),0,false,Constants.MatchLeftNormal+Constants.Roboto, new int[]{0,0,0,0});
        components.CustomizeEditview(ctgry_edtx, Constants.Medium,R.color.thik_grey,R.color.thik_grey,getActivity().getApplicationContext().getResources().getString(R.string.seclt_catgry),0,false,Constants.MatchLeftNormal+Constants.Roboto, new int[]{0,0,0,0});
        components.CustomizeEditview(discount_edtx, Constants.Medium,R.color.thik_grey,R.color.thik_grey,getActivity().getApplicationContext().getResources().getString(R.string.dscunt_type),0,false,Constants.MatchLeftNormal+Constants.Roboto, new int[]{0,0,0,0});
        components.CustomizeEditview(seloffer_edtx, Constants.Medium,R.color.thik_grey,R.color.thik_grey,getActivity().getApplicationContext().getResources().getString(R.string.ofrstatus_type),0,false,Constants.MatchLeftNormal+Constants.Roboto, new int[]{0,0,0,0});
        components.CustomizeEditview(adofr_dsplydate_et, Constants.Small,R.color.thik_grey,R.color.thik_grey,getActivity().getApplicationContext().getResources().getString(R.string.disply_strtdate),0,false,Constants.MatchLeftNormal+Constants.Roboto, new int[]{0,0,0,0});
        components.CustomizeEditview(adofr_dsplyenddate_et, Constants.Small,R.color.thik_grey,R.color.thik_grey,getActivity().getApplicationContext().getResources().getString(R.string.disply_enddate),0,false,Constants.MatchLeftNormal+Constants.Roboto, new int[]{0,0,0,0});
        components.CustomizeTextview(adofr_strtdate_tx, Constants.Small,R.color.sport_shoos_txt_clr,getActivity().getApplicationContext().getResources().getString(R.string.start_date),Constants.WrapCenterNormal+Constants.Roboto, new int[]{5,6,5,6});
        components.CustomizeTextview(adofr_enddate_tx, Constants.Small,R.color.sport_shoos_txt_clr,getActivity().getApplicationContext().getResources().getString(R.string.end_date),Constants.WrapCenterNormal+Constants.Roboto, new int[]{5,6,5,6});
        components.CustomizeImageview(adofr_dsplydate_img, new int[]{14,16}, R.drawable.calender_icon, new int[]{0,0,5,0});
        components.CustomizeImageview(adofr_dsplyendate_img, new int[]{14,16}, R.drawable.calender_icon, new int[]{0,0,5,0});

        components.CustomizeButton(filter_done_btn, Constants.XXNormal,R.color.white,getActivity().getApplicationContext().getResources().getString(R.string.srch),R.drawable.list_bottom_bg,Constants.MatchCenterNormal+Constants.Roboto, new int[]{0,42}, new int[]{0,10,0,5});

        Drawable d = new ColorDrawable(Color.WHITE);

        d.setAlpha(200);

        mPopupWindow.setBackgroundDrawable(new BitmapDrawable());

        mPopupWindow.showAsDropDown(viewpager_lay,0,0, Gravity.CENTER);

        //getWindow().setBackgroundDrawable(d);

        mPopupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
                Drawable d = new ColorDrawable(Color.WHITE);
                //getWindow().setBackgroundDrawable(d);
            }
        });


        select_ctgry_lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        select_subctgry_lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        filter_done_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mPopupWindow.dismiss();
            }
        });


    }

}
