package com.o3sa.mobipugapp.fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.o3sa.mobipugapp.R;
import com.o3sa.mobipugapp.uicomponents.BasicComponents;
import com.o3sa.mobipugapp.uicomponents.Constants;

/**
 * Created by Kiran on 27-10-2018.
 */

public class VendorAddSubCategory extends Fragment {

    EditText amount_edtx;

    Button generatebill_btn;

    BasicComponents components;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.generatebill,container,false);

        components=new BasicComponents(getActivity());
        intialization(v);

        return v;
    }

    public void intialization(View v){
        generatebill_btn = (Button)v.findViewById(R.id.generatebill_btn);
        amount_edtx =(EditText)v.findViewById(R.id.amount_edtx);
        assigndata();
    }

    public void assigndata(){
        components.CustomizeButton(generatebill_btn, Constants.XXNormal,R.color.white,getActivity().getApplicationContext().getResources().getString(R.string.submit),R.drawable.list_bottom_bg,Constants.MatchCenterBold+Constants.Roboto, new int[]{0,42}, new int[]{0,20,0,30});
        components.CustomizeEditview(amount_edtx, Constants.Medium,R.color.thik_grey,R.color.black,getActivity().getApplicationContext().getResources().getString(R.string.subcategoryname),R.drawable.shadoweffect,true,Constants.MatchLeftNormal+Constants.Roboto, new int[]{0,10,0,0});
    }

}



