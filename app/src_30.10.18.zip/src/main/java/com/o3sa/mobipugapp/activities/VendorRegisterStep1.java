package com.o3sa.mobipugapp.activities;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.o3sa.mobipugapp.R;
import com.o3sa.mobipugapp.uicomponents.BasicComponents;
import com.o3sa.mobipugapp.uicomponents.Constants;

import static android.view.Gravity.TOP;

/**
 * Created by android_2 on 10/27/2018.
 */

public class VendorRegisterStep1 extends Fragment {

    EditText vreg_busnme_edtx,vreg_bus_imgupld_edtx,vreg_bus_bg_imgupld_edtx,vreg_slct_catgry_edtx,vreg_slct_subcatgry_edtx,vreg_abutus_edtx;
    ImageView vreg_bus_imgupld_img,vreg_bus_bg_imgupld_img,vreg_slct_catgry_img,vreg_slct_subcatgry_img;
    Button vreg_cntnue_btnn;

    BasicComponents components;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.vendor_register_step1,container,false);
        components = new BasicComponents(getActivity());

        intialization(v);
        return v;
    }

    public void intialization(View v){

        vreg_busnme_edtx =(EditText)v.findViewById(R.id.vreg_busnme_edtx);
        vreg_bus_imgupld_edtx =(EditText)v.findViewById(R.id.vreg_bus_imgupld_edtx);
        vreg_bus_bg_imgupld_edtx =(EditText)v.findViewById(R.id.vreg_bus_bg_imgupld_edtx);
        vreg_slct_catgry_edtx =(EditText)v.findViewById(R.id.vreg_slct_catgry_edtx);
        vreg_slct_subcatgry_edtx =(EditText)v.findViewById(R.id.vreg_slct_subcatgry_edtx);
        vreg_abutus_edtx =(EditText)v.findViewById(R.id.vreg_abutus_edtx);

        vreg_bus_imgupld_img=(ImageView)v.findViewById(R.id.vreg_bus_imgupld_img);
        vreg_bus_bg_imgupld_img=(ImageView)v.findViewById(R.id.vreg_bus_bg_imgupld_img);
        vreg_slct_catgry_img = (ImageView)v.findViewById(R.id.vreg_slct_catgry_img);
        vreg_slct_subcatgry_img = (ImageView)v.findViewById(R.id.vreg_slct_subcatgry_img);


        vreg_cntnue_btnn=(Button) v.findViewById(R.id.vreg_cntnue_btnn);


        assigndata();
    }

    public void assigndata() {

        components.CustomizeEditview(vreg_busnme_edtx, Constants.Medium, R.color.black, R.color.white, getActivity().getApplicationContext().getResources().getString(R.string.businessname),R.drawable.shadoweffect, true, Constants.MatchCenterNormal + Constants.Roboto, new int[]{0,0,0,0});
        components.CustomizeEditview(vreg_bus_imgupld_edtx, Constants.Medium, R.color.black, R.color.white, getActivity().getApplicationContext().getResources().getString(R.string.businesspic),0, true, Constants.MatchCenterNormal + Constants.Roboto, new int[]{0,0,0,0});
        components.CustomizeEditview(vreg_bus_bg_imgupld_edtx, Constants.Medium, R.color.black, R.color.white, getActivity().getApplicationContext().getResources().getString(R.string.businessbgpic),0, true, Constants.MatchCenterNormal + Constants.Roboto, new int[]{0,0,0,0});
        components.CustomizeEditview(vreg_slct_catgry_edtx, Constants.Medium, R.color.black, R.color.white, getActivity().getApplicationContext().getResources().getString(R.string.categorytype),0, true, Constants.MatchCenterNormal + Constants.Roboto, new int[]{0,0,0,0});
        components.CustomizeEditview(vreg_slct_subcatgry_edtx, Constants.Medium, R.color.black, R.color.white, getActivity().getApplicationContext().getResources().getString(R.string.ifcs_code_mndtry),0, true, Constants.MatchCenterNormal + Constants.Roboto, new int[]{0,0,0,0});
        components.CustomizeMultilineEditview(vreg_abutus_edtx,Constants.Medium,R.color.black,R.color.white,getActivity().getApplicationContext().getResources().getString(R.string.aboutus),R.drawable.shadoweffect,true,false,Constants.MatchLeftNormal+Constants.Roboto, new int[]{0,15,0,0},3);

        vreg_abutus_edtx.setGravity(Gravity.LEFT|TOP);

        components.CustomizeImageview(vreg_bus_imgupld_img, new int[]{20,15},R.drawable.dropdown_icon, new int[]{0,0,0,0});
        components.CustomizeImageview(vreg_bus_bg_imgupld_img, new int[]{20,15},R.drawable.dropdown_icon, new int[]{0,0,0,0});
        components.CustomizeImageview(vreg_slct_catgry_img, new int[]{20,15},R.drawable.dropdown_icon, new int[]{0,0,0,0});
        components.CustomizeImageview(vreg_slct_subcatgry_img, new int[]{20,15},R.drawable.dropdown_icon, new int[]{0,0,0,0});


        components.CustomizeButton(vreg_cntnue_btnn, Constants.Normal,R.color.white,getActivity().getApplicationContext().getResources().getString(R.string.cntinue),R.drawable.cntinue_btn_bg,Constants.MatchCenterNormal+Constants.SFUIText, new int[]{0,45}, new int[]{0,15,0,35});

    }

}
