package com.o3sa.mobipugapp.fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.o3sa.mobipugapp.R;
import com.o3sa.mobipugapp.dumpdata.DumpData;
import com.o3sa.mobipugapp.dumpdata.StoredObjects;
import com.o3sa.mobipugapp.sidemenu.Sidemenu;
import com.o3sa.mobipugapp.uicomponents.BasicComponents;
import com.o3sa.mobipugapp.uicomponents.Constants;
import com.o3sa.mobipugapp.uicomponents.CustomRecyclerview;

/**
 * Created by Kiran on 27-10-2018.
 */

public class VendorManageCategory  extends Fragment {

    public static RecyclerView c_categorylist;
    BasicComponents components;

    ImageView ctgy_search_img;
    EditText ctgy_search_tx;
    String[] sbcat_names  = {"Starters","Main Course","Desserts","Combos","Mia Addison","Sophia Lily","Emily Olivia"};

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.customercategorylist,container,false);

        components=new BasicComponents(getActivity());

        intialization(v);
        Assigndata();
        return v;
    }

    private void Assigndata() {
        components.CustomizeImageview(ctgy_search_img, new int[]{20,20}, R.drawable.pink_searchicon, new int[]{0,0,0,0});
        components.CustomizeEditview(ctgy_search_tx, Constants.Medium,R.color.thik_grey,R.color.thik_grey,getActivity().getApplicationContext().getResources().getString(R.string.search),0,true,Constants.MatchLeftNormal+Constants.Roboto, new int[]{8,0,0,0});

    }

    public void intialization(View v){

        c_categorylist = (RecyclerView)v.findViewById(R.id.c_categorylist);
        ctgy_search_img=(ImageView) v.findViewById(R.id.ctgy_search_img);
        ctgy_search_tx=(EditText) v.findViewById(R.id.ctgy_search_tx);

        StoredObjects.subcategoryarraylist.clear();

        for (int i = 0;i<sbcat_names.length;i++){
            DumpData dumpData = new DumpData();
            dumpData.sbcat_nmslist = sbcat_names[i];

            StoredObjects.subcategoryarraylist.add(dumpData);
        }

        CustomRecyclerview recyclerview = new CustomRecyclerview(getActivity());
        recyclerview.Assigndatatorecyleview(c_categorylist,StoredObjects.subcategoryarraylist,"c_mangecategrylist", Constants.Listview,0, Constants.ver_orientation,R.layout.c_managecategoryitem);

    }



}
