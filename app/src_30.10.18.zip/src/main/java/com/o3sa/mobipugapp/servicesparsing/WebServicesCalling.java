package com.o3sa.mobipugapp.servicesparsing;

import android.app.Activity;
import android.os.AsyncTask;
import android.widget.Toast;

import com.o3sa.mobipugapp.dumpdata.StoredObjects;

import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.SocketTimeoutException;
import java.net.URISyntaxException;

public class WebServicesCalling {

    Activity this_activity;
    int this_int;

    public WebServicesCalling(Activity activity) {

        this.this_activity = activity;

    }



    public void calling_webservices(String url,String paramaters,int this_int){

        if (InterNetChecker.isNetworkAvailable(this_activity)) {
            this.this_int = this_int;
            ServicesDetails details_param = new ServicesDetails();

            details_param.url = url;

                String[] param_split = paramaters.split("&", 10);

                for(int i =0;i<param_split.length;i++){

                    String[] param_inner_split = url.split("=", 2);
                     if(param_inner_split.length == 0){

                     }

                    else if(param_inner_split.length == 1){
                         details_param.nameValuePairs.add(new BasicNameValuePair(param_inner_split[0],""));
                    }else{
                         details_param.nameValuePairs.add(new BasicNameValuePair(param_inner_split[0],param_inner_split[1]));
                    }

                }

                StoredObjects.Services_list.remove(this_int);
                StoredObjects.Services_list.add(this_int,details_param);

            new Calling_service().execute();

        }else{
            Toast.makeText(this_activity, "Please Check Internet Connection.", Toast.LENGTH_SHORT).show();
        }

    }



    public class Calling_service extends AsyncTask<String, String, String> {

        String strResult = "";

        @Override
        protected void onPreExecute() {
           //ProgressBar_Class.Progressbarshow(this_activity);
        }

        @Override
        protected String doInBackground(String... params) {
            try {

            //List<NameValuePair> nameValuePairs =  //new ArrayList<NameValuePair>(20);

            strResult = HttpPostClass.PostMethod(StoredObjects.base_url + StoredObjects.Services_list.get(this_int).url , StoredObjects.Services_list.get(this_int).nameValuePairs);

            } catch (URISyntaxException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SocketTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (ConnectTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (UnsupportedEncodingException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            StoredObjects.Services_list.get(0).Result = strResult;

            return strResult;

        }

        protected void onPostExecute(String results) {

            if (results != null) {
              //ProgressBar_Class.Progressbarcancel(this_activity);
            }

            String status;

            try {
                JSONObject jsonrootObject =  new JSONObject(results);
                status = jsonrootObject.getString("status");
                StoredObjects.LogMethod("status", "status:--"+status);

                try {
                    if(status.equalsIgnoreCase("200")){
                        String res = jsonrootObject.getString("results");
                        StoredObjects.LogMethod("status_res", "status_res:--"+res);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }catch (JSONException e1) {
                // TODO Auto-generated catch block
                StoredObjects.LogMethod("status_res", "status_res:--"+e1);
                e1.printStackTrace();
            }catch (Exception e) {
                StoredObjects.LogMethod("status_res", "status_res:--"+e);
                e.printStackTrace();
            }

        }

    }



}
