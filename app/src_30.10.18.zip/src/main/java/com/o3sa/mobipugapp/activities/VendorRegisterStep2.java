package com.o3sa.mobipugapp.activities;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.o3sa.mobipugapp.R;
import com.o3sa.mobipugapp.uicomponents.BasicComponents;
import com.o3sa.mobipugapp.uicomponents.Constants;

import static android.view.Gravity.TOP;

/**
 * Created by android_2 on 10/27/2018.
 */

public class VendorRegisterStep2 extends Fragment {

    EditText vreg_latitude_edtx,vreg_longitude_edtx,vreg_telephne_edtx,vreg_fax_edtx,vreg_email_edtx,vreg_bus_adres_edtx,
            vreg_map_adres_edtx,vreg_pincde_edtx,vreg_website_edtx;

    ImageView vreg_email_img;

    Button vreg_sbmt_btn;

    BasicComponents components;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.vendor_register_step2,container,false);
        components = new BasicComponents(getActivity());

        intialization(v);
        return v;
    }

    public void intialization(View v){

        vreg_latitude_edtx =(EditText)v.findViewById(R.id.vreg_latitude_edtx);
        vreg_longitude_edtx =(EditText)v.findViewById(R.id.vreg_longitude_edtx);
        vreg_telephne_edtx =(EditText)v.findViewById(R.id.vreg_telephne_edtx);
        vreg_fax_edtx =(EditText)v.findViewById(R.id.vreg_fax_edtx);
        vreg_email_edtx =(EditText)v.findViewById(R.id.vreg_email_edtx);
        vreg_bus_adres_edtx =(EditText)v.findViewById(R.id.vreg_bus_adres_edtx);
        vreg_map_adres_edtx = (EditText)v.findViewById(R.id.vreg_map_adres_edtx);
        vreg_pincde_edtx = (EditText)v.findViewById(R.id.vreg_pincde_edtx);
        vreg_website_edtx = (EditText)v.findViewById(R.id.vreg_website_edtx);

        vreg_email_img=(ImageView)v.findViewById(R.id.vreg_email_img);


        vreg_sbmt_btn=(Button) v.findViewById(R.id.vreg_sbmt_btn);


        assigndata();
    }

    public void assigndata() {

        components.CustomizeEditview(vreg_latitude_edtx, Constants.Medium, R.color.black, R.color.white, getActivity().getApplicationContext().getResources().getString(R.string.latitude),R.drawable.shadoweffect, true, Constants.MatchCenterNormal + Constants.Roboto, new int[]{0,0,0,0});
        components.CustomizeEditview(vreg_longitude_edtx, Constants.Medium, R.color.black, R.color.white, getActivity().getApplicationContext().getResources().getString(R.string.longitude),R.drawable.shadoweffect, true, Constants.MatchCenterNormal + Constants.Roboto, new int[]{0,15,0,0});
        components.CustomizeEditview(vreg_telephne_edtx, Constants.Medium, R.color.black, R.color.white, getActivity().getApplicationContext().getResources().getString(R.string.telephone),R.drawable.shadoweffect, true, Constants.MatchCenterNormal + Constants.Roboto, new int[]{0,15,0,0});
        components.CustomizeEditview(vreg_fax_edtx, Constants.Medium, R.color.black, R.color.white, getActivity().getApplicationContext().getResources().getString(R.string.fax),R.drawable.shadoweffect, true, Constants.MatchCenterNormal + Constants.Roboto, new int[]{0,15,0,0});
        components.CustomizeEditview(vreg_email_edtx, Constants.Medium, R.color.black, R.color.white, getActivity().getApplicationContext().getResources().getString(R.string.email_mndtry),0, true, Constants.MatchCenterNormal + Constants.Roboto, new int[]{0,0,0,0});
        components.CustomizeEditview(vreg_pincde_edtx, Constants.Medium, R.color.black, R.color.white, getActivity().getApplicationContext().getResources().getString(R.string.pincode_mndtry),R.drawable.shadoweffect, true, Constants.MatchCenterNormal + Constants.Roboto, new int[]{0,15,0,0});
        components.CustomizeEditview(vreg_website_edtx, Constants.Medium, R.color.black, R.color.white, getActivity().getApplicationContext().getResources().getString(R.string.website),R.drawable.shadoweffect, true, Constants.MatchCenterNormal + Constants.Roboto, new int[]{0,15,0,0});

        components.CustomizeMultilineEditview(vreg_bus_adres_edtx,Constants.Medium,R.color.black,R.color.white,getActivity().getApplicationContext().getResources().getString(R.string.bussinessaddress),R.drawable.shadoweffect,true,false,Constants.MatchLeftNormal+Constants.Roboto, new int[]{0,15,0,0},3);
        components.CustomizeMultilineEditview(vreg_map_adres_edtx,Constants.Medium,R.color.black,R.color.white,getActivity().getApplicationContext().getResources().getString(R.string.mapaddress),R.drawable.shadoweffect,true,false,Constants.MatchLeftNormal+Constants.Roboto, new int[]{0,15,0,0},3);

        vreg_bus_adres_edtx.setGravity(Gravity.LEFT|TOP);
        vreg_map_adres_edtx.setGravity(Gravity.LEFT|TOP);

        components.CustomizeImageview(vreg_email_img, new int[]{20,15},R.drawable.dropdown_icon, new int[]{0,0,0,0});

        components.CustomizeButton(vreg_sbmt_btn, Constants.Normal,R.color.white,getActivity().getApplicationContext().getResources().getString(R.string.submit_),R.drawable.cntinue_btn_bg,Constants.MatchCenterNormal+Constants.SFUIText, new int[]{0,45}, new int[]{0,15,0,35});
    }
}
