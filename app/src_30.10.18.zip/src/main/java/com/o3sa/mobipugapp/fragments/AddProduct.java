package com.o3sa.mobipugapp.fragments;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;

import com.o3sa.mobipugapp.R;
import com.o3sa.mobipugapp.dumpdata.StoredObjects;
import com.o3sa.mobipugapp.uicomponents.BasicComponents;
import com.o3sa.mobipugapp.uicomponents.Constants;

import java.util.Calendar;

/**
 * Created by Kiran on 21-10-2018.
 */

public class AddProduct extends Fragment {

    EditText addprdctname_edtx,addprdctdescr_edtx,prdctctgry_edtx,prdctsubctgry_edtx;//adprdctprice_edtx
    TextView addprdctdescr_tx,adprdctimage_tx,adprdctimgpick_tx,camera_tx,gallery_tx,stock_tx;//adprdctdetls_tx
    RadioButton avalblepro_rbtn,notavalblepro_rbtn;
    Button addproduct_btn;
    //ImageView addmsmnt_btn;

    BasicComponents components;
    LinearLayout main_msrmnt_lay,addpikedimgs_lay;//addmeasurmntlay

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.addproduct,container,false);

        components=new BasicComponents(getActivity());
        intialization(v);

        return v;
    }

    public void intialization(View v){
        addprdctdescr_tx =(TextView) v.findViewById(R.id.addprdctdescr_tx);
        adprdctimage_tx= (TextView)v.findViewById(R.id.adprdctimage_tx);
        adprdctimgpick_tx =(TextView)v.findViewById(R.id.adprdctimgpick_tx);
        camera_tx =(TextView)v.findViewById(R.id.camera_tx);
        gallery_tx =(TextView)v.findViewById(R.id.gallery_tx);
        stock_tx =(TextView)v.findViewById(R.id.stock_tx);
        avalblepro_rbtn = (RadioButton)v.findViewById(R.id.avalblepro_rbtn);
        notavalblepro_rbtn = (RadioButton)v.findViewById(R.id.notavalblepro_rbtn);
        addproduct_btn = (Button)v.findViewById(R.id.addproduct_btn);
        addprdctname_edtx =(EditText)v.findViewById(R.id.addprdctname_edtx);
        addprdctdescr_edtx =(EditText)v.findViewById(R.id.addprdctdescr_edtx);
        prdctctgry_edtx =(EditText)v.findViewById(R.id.prdctctgry_edtx);
        prdctsubctgry_edtx=(EditText)v.findViewById(R.id.prdctsubctgry_edtx);
        main_msrmnt_lay=(LinearLayout) v.findViewById(R.id.main_msrmnt_lay);

        addpikedimgs_lay=(LinearLayout) v.findViewById(R.id.addpikedimgs_lay);
        avalblepro_rbtn.setChecked(false);
        notavalblepro_rbtn.setChecked(false);

        avalblepro_rbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(avalblepro_rbtn.isChecked())
                {
                    avalblepro_rbtn.setChecked(true);
                    notavalblepro_rbtn.setChecked(false);
                }
            }
        });

        notavalblepro_rbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(notavalblepro_rbtn.isChecked())
                {
                    notavalblepro_rbtn.setChecked(true);
                    avalblepro_rbtn.setChecked(false);
                }
            }
        });


        assigndata();

    }

    public void assigndata(){

        components.CustomizeEditview(prdctctgry_edtx, Constants.Medium,R.color.thik_grey,R.color.thik_grey,getActivity().getApplicationContext().getResources().getString(R.string.sel_category),0,true,Constants.MatchLeftNormal+Constants.Roboto, new int[]{0,0,0,0});
        components.CustomizeEditview(prdctsubctgry_edtx, Constants.Medium,R.color.thik_grey,R.color.thik_grey,getActivity().getApplicationContext().getResources().getString(R.string.sel_subcategory),0,true,Constants.MatchLeftNormal+Constants.Roboto, new int[]{0,0,0,0});

        components.CustomizeTextview(addprdctdescr_tx, Constants.Medium,R.color.thik_grey,getActivity().getApplicationContext().getResources().getString(R.string.product_descr),Constants.WrapLeftNormal+Constants.Roboto, new int[]{10,10,0,10});
        components.CustomizeTextview(adprdctimage_tx,Constants.Normal,R.color.blue_color,getActivity().getApplicationContext().getResources().getString(R.string.product_imgs),Constants.WrapLeftNormal+Constants.Roboto, new int[]{10,10,0,10});
        components.CustomizeTextview(adprdctimgpick_tx,Constants.Small,R.color.black,getActivity().getApplicationContext().getResources().getString(R.string.product_pick),Constants.WrapLeftNormal+Constants.Roboto, new int[]{15,0,0,0});
        components.CustomizeTextview(stock_tx,Constants.Normal,R.color.blue_color,getActivity().getApplicationContext().getResources().getString(R.string.stock),Constants.WrapLeftNormal+Constants.Roboto, new int[]{10,10,10,0});
        components.CustomizeButton(addproduct_btn, Constants.XNormal,R.color.white,getActivity().getApplicationContext().getResources().getString(R.string.save),R.drawable.list_bottom_bg,Constants.MatchCenterNormal+Constants.Roboto, new int[]{0,50}, new int[]{0,20,0,30});
        components.CustomizeEditview(addprdctname_edtx, Constants.Medium,R.color.thik_grey,R.color.thik_grey,getActivity().getApplicationContext().getResources().getString(R.string.product_name),R.drawable.shadoweffect,true,Constants.MatchLeftNormal+Constants.Roboto, new int[]{0,10,0,10});
        components.CustomizeMultilineEditview(addprdctdescr_edtx,Constants.Medium,R.color.thik_grey,R.color.thik_grey,getActivity().getApplicationContext().getResources().getString(R.string.product_descrempty),R.drawable.shadoweffect,true,false,Constants.MatchLeftNormal+Constants.Roboto, new int[]{0,10,0,10},4);


        main_msrmnt_lay.removeAllViews();
        for (int i = 0; i <1; i++) {
            addlayout(main_msrmnt_lay);
        }
        addpikedimgs_lay.removeAllViews();
        for (int i = 0; i <3; i++) {
            addimageslayout(addpikedimgs_lay);
        }
    }
    public void addsublayout(final LinearLayout layout){
        View v	=LayoutInflater.from(getActivity()).inflate(R.layout.addmeasrmnt_item, null);
        EditText mesrmntname_edt=(EditText) v.findViewById(R.id.mesrmntname_edt);
        EditText mesrmntval_edt=(EditText) v.findViewById(R.id.mesrmntval_edt);
        EditText mesrmntunit_edt=(EditText) v.findViewById(R.id.mesrmntunit_edt);
        ImageView addmoremsmnt_btn=(ImageView) v.findViewById(R.id.addmoremsmnt_btn);

        addmoremsmnt_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                for (int i = 0; i <1; i++) {
                    addsublayout(layout);
                }
            }
        });
        layout.addView(v);
    }
    public void addlayout(LinearLayout layout){
        View v	=LayoutInflater.from(getActivity()).inflate(R.layout.main_msrmnt_listitem, null);
        EditText adprdctprice_edtx=(EditText) v.findViewById(R.id.adprdctprice_edtx);
        TextView adprdctdetls_tx=(TextView) v.findViewById(R.id.adprdctdetls_tx);
        ImageView addmsmnt_btn=(ImageView) v.findViewById(R.id.addmsmnt_btn);
        final LinearLayout addmeasurmntlay=(LinearLayout) v.findViewById(R.id.addmeasurmntlay);
        components.CustomizeEditview(adprdctprice_edtx, Constants.Medium,R.color.thik_grey,R.color.thik_grey,getActivity().getApplicationContext().getResources().getString(R.string.amount),R.drawable.shadoweffect,true,Constants.MatchLeftNormal+Constants.Roboto, new int[]{10,10,10,10});
        components.CustomizeTextview(adprdctdetls_tx,Constants.Normal,R.color.blue_color,getActivity().getApplicationContext().getResources().getString(R.string.product_details),Constants.WrapCenterNormal+Constants.Roboto, new int[]{0,0,0,0});

        addmeasurmntlay.removeAllViews();
        for (int i = 0; i <1; i++) {
            addsublayout(addmeasurmntlay);
        }
        addmsmnt_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (int i = 0; i <1; i++) {
                    addlayout(main_msrmnt_lay);
                }
            }
        });
        layout.addView(v);
    }
    public void addimageslayout(LinearLayout layout){
        View v	=LayoutInflater.from(getActivity()).inflate(R.layout.addimages_item, null);
        ImageView addpicked_img=(ImageView) v.findViewById(R.id.addpicked_img);
        components.CustomizeImageview(addpicked_img, new int[]{100,100}, R.drawable.restarunt_sammpleimg, new int[]{0,0,0,0});

        layout.addView(v);
    }

}

